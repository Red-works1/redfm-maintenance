/* RED FM Maintenance — shared data layer
   Signs in the shared maintenance account (MSAL) and reads/writes the
   SharePoint lists via Microsoft Graph. Used by every capture form + the dashboard.

   SETUP: after IT does the app registration, paste the Application (client) ID below.
   Load MSAL before this file:
   <script src="https://alcdn.msauth.net/browser/2.38.3/js/msal-browser.min.js"></script>
   <script src="redfm-data.js"></script>
*/
window.REDFM = (function () {
  const CONFIG = {
    clientId: "9de89aff-4367-4355-808d-f9fccbb1f974",     // RED FM Maintenance Web App registration
    tenantId: "63dfe382-90e1-467d-926e-af043415e67f",     // Red Refrigeration Bristol
    siteHostname: "redbristol.sharepoint.com",
    sitePath: "/sites/REDFMMaintenance",
    scopes: ["Sites.ReadWrite.All"]
  };

  const msalConfig = {
    auth: {
      clientId: CONFIG.clientId,
      authority: "https://login.microsoftonline.com/" + CONFIG.tenantId,
      redirectUri: window.location.origin   // must match a registered SPA redirect URI (site root)
    },
    cache: { cacheLocation: "localStorage" }   // keeps the engineer signed in between visits
  };

  let msalApp, account, siteId = null;
  const listIds = {};

  async function init() {
    msalApp = new window.msal.PublicClientApplication(msalConfig);
    if (msalApp.initialize) await msalApp.initialize();
    const redirect = await msalApp.handleRedirectPromise();
    account = redirect ? redirect.account : (msalApp.getAllAccounts()[0] || null);
    return !!account;
  }

  async function signIn() {
    const r = await msalApp.loginPopup({ scopes: CONFIG.scopes });
    account = r.account;
    return account;
  }

  function signOut() { return msalApp.logoutPopup({ account }); }
  function getAccount() { return account; }

  async function getToken() {
    try {
      const r = await msalApp.acquireTokenSilent({ scopes: CONFIG.scopes, account });
      return r.accessToken;
    } catch (e) {
      const r = await msalApp.acquireTokenPopup({ scopes: CONFIG.scopes });
      account = r.account; return r.accessToken;
    }
  }

  async function graph(path, method, body) {
    const token = await getToken();
    const res = await fetch("https://graph.microsoft.com/v1.0" + path, {
      method: method || "GET",
      headers: { Authorization: "Bearer " + token, "Content-Type": "application/json" },
      body: body ? JSON.stringify(body) : undefined
    });
    if (!res.ok) throw new Error("Graph " + res.status + ": " + (await res.text()));
    return res.status === 204 ? null : res.json();
  }

  async function getSiteId() {
    if (siteId) return siteId;
    const s = await graph("/sites/" + CONFIG.siteHostname + ":" + CONFIG.sitePath);
    return (siteId = s.id);
  }

  async function getListId(title) {
    if (listIds[title]) return listIds[title];
    const sid = await getSiteId();
    const r = await graph("/sites/" + sid + "/lists?$select=id,displayName&$top=100");
    r.value.forEach(l => (listIds[l.displayName] = l.id));
    return listIds[title];
  }

  async function listItems(title, filterFn) {
    const sid = await getSiteId();
    const lid = await getListId(title);
    let url = "/sites/" + sid + "/lists/" + lid + "/items?$expand=fields&$top=500";
    const out = [];
    while (url) {
      const page = await graph(url);
      page.value.forEach(i => { if (!filterFn || filterFn(i.fields)) out.push(i.fields); });
      url = page["@odata.nextLink"] ? page["@odata.nextLink"].replace("https://graph.microsoft.com/v1.0", "") : null;
    }
    return out;
  }

  // The reading definitions for a service type, in order (e.g. "Weekly", "Quarterly A&B")
  async function getCatalogue(serviceType) {
    const rows = await listItems("ReadingCatalogue", f => f.ServiceType === serviceType);
    return rows.sort((a, b) => (a.SortOrder || 0) - (b.SortOrder || 0));
  }

  async function addItem(title, fields) {
    const sid = await getSiteId();
    const lid = await getListId(title);
    return graph("/sites/" + sid + "/lists/" + lid + "/items", "POST", { fields });
  }

  // Create many items fast using Graph $batch (20 per request) — a weekly sheet is 100+ rows.
  async function addItemsBatch(title, fieldsArray) {
    const sid = await getSiteId();
    const lid = await getListId(title);
    const url = "/sites/" + sid + "/lists/" + lid + "/items";
    const results = [];
    for (let i = 0; i < fieldsArray.length; i += 20) {
      const requests = fieldsArray.slice(i, i + 20).map((f, n) => ({
        id: String(n), method: "POST", url: url,
        headers: { "Content-Type": "application/json" }, body: { fields: f }
      }));
      const res = await graph("/$batch", "POST", { requests });
      results.push(...res.responses);
    }
    const failed = results.filter(r => r.status >= 300);
    if (failed.length) throw new Error(failed.length + " of " + fieldsArray.length + " readings failed to save");
    return results;
  }

  // Save a visit header + all its reading line-items. Returns the created visit.
  // Columns added in the Aug-2026 fault-capture phase. If SharePoint has not been
  // updated yet a POST carrying them 400s — never lose a whole visit over that.
  const NEW_VISIT_FIELDS = ["FaultsFlagged", "FaultsDocumented"];
  async function saveVisit(visitFields, readingRows) {
    let visit;
    try {
      visit = await addItem("ServiceVisits", visitFields);
    } catch (e) {
      const lean = Object.assign({}, visitFields);
      NEW_VISIT_FIELDS.forEach(k => delete lean[k]);
      if (lean.Status === "Awaiting fault detail") lean.Status = "Partially completed";
      visit = await addItem("ServiceVisits", lean);
    }
    const ref = visitFields.Title || ("SV-" + visit.id);
    const rows = readingRows.map(rd => Object.assign({ VisitRef: ref }, rd));
    if (rows.length) await addItemsBatch("Readings", rows);
    return visit;
  }

  // Read everything the dashboard needs
  async function getServiceVisits() { return listItems("ServiceVisits"); }
  async function getFaults() { return listItems("FaultRegister"); }
  async function getReadings() { return listItems("Readings"); }
  async function getCatalogueAll() { return listItems("ReadingCatalogue"); }

  // Faults including the SharePoint item id (needed to update stage / action).
  async function getFaultsWithId() {
    const sid = await getSiteId();
    const lid = await getListId("FaultRegister");
    let url = "/sites/" + sid + "/lists/" + lid + "/items?$expand=fields&$top=500";
    const out = [];
    while (url) {
      const page = await graph(url);
      page.value.forEach(i => { const f = i.fields || {}; f._id = i.id; out.push(f); });
      url = page["@odata.nextLink"] ? page["@odata.nextLink"].replace("https://graph.microsoft.com/v1.0", "") : null;
    }
    return out;
  }

  // Update a fault's stage / action notes. Caller is a signed-in RED / Coolstream user.
  async function updateFault(id, fields) {
    const sid = await getSiteId();
    const lid = await getListId("FaultRegister");
    return graph("/sites/" + sid + "/lists/" + lid + "/items/" + id + "/fields", "PATCH", fields);
  }

  // Patch a ServiceVisit (fault counters, Status) — used by the fault capture flow.
  async function updateVisit(id, fields) {
    const sid = await getSiteId();
    const lid = await getListId("ServiceVisits");
    return graph("/sites/" + sid + "/lists/" + lid + "/items/" + id + "/fields", "PATCH", fields);
  }

  // Find a visit's SharePoint item id from its ref (Title), for flows that only kept the ref.
  async function getVisitIdByRef(ref) {
    const items = await getServiceVisits();
    const hit = items.find(v => (v.Title || "") === ref);
    return hit ? (hit.id || hit.ID || null) : null;
  }

  // ---- Canonical asset identity -------------------------------------------------
  // Readings are already stored with Asset = variant + " " + column (e.g. "E E2").
  // Faults must resolve to the SAME code so per-asset history and repeat counters
  // can join the two. One function, used by forms, dashboard and view.html.
  function assetId(variant, section, col) {
    const v = String(variant || "").trim();
    const c = String(col || "").trim();
    if (!c) return v;
    if (/^(no\d\s+)?[a-e]\d/i.test(c)) return c;              // E2, C1, A4, No1 B2, E1 Compr1
    if (/^(kwhr|°c|c)$/i.test(c)) return (v + " — " + (section || "")).trim();  // units, not assets
    return (v + " " + c).trim();
  }

  // ---- Document library uploads (client-side) ----
  const driveIds = {};
  async function getDriveId(name) {
    if (driveIds[name]) return driveIds[name];
    const sid = await getSiteId();
    const d = await graph("/sites/" + sid + "/drives?$select=id,name&$top=50");
    d.value.forEach(x => (driveIds[x.name] = x.id));
    return driveIds[name];
  }

  // Upload a Blob to a named document library (e.g. "Reports", "Faults"). Returns the created file (incl. webUrl).
  async function uploadFile(libraryName, filename, blob, contentType) {
    const token = await getToken();
    const sid = await getSiteId();
    const did = await getDriveId(libraryName);
    if (!did) throw new Error("Library not found: " + libraryName);
    const safe = filename.replace(/[\\/:*?"<>|#%]+/g, "-");
    const res = await fetch("https://graph.microsoft.com/v1.0/sites/" + sid + "/drives/" + did +
      "/root:/" + encodeURIComponent(safe) + ":/content", {
      method: "PUT",
      headers: { Authorization: "Bearer " + token, "Content-Type": contentType || "application/octet-stream" },
      body: blob
    });
    if (!res.ok) throw new Error("Upload " + res.status + ": " + (await res.text()));
    return res.json();
  }
  // Back-compat: file a PDF into the Reports library.
  function uploadReportPdf(filename, blob) { return uploadFile("Reports", filename, blob, "application/pdf"); }

  const RED = [0xE0, 0x13, 0x22];
  // F-Gas Certification scheme mark (from Coolstream's Refcom cert) — shown on F-Gas certificates only.
  const FGAS_LOGO = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAbgAAADGCAIAAAAv9wLhAACStElEQVR42u19d5wcxZl2vVUdJs9GSauchSJBIkchRM4ZG+ds7nw2d85EgzEGY8A4258DvrNNRoggESSEECChjFY5sYq7q42zO6m76v3+qJ3RhO6enpmVtBJbPx83mp3p6a7wvPl5ARFJ/+gf/aN/9A/7QfunoH/0j/7RP/qBsn/0j/7RP/qBsn/0j/7RP/qBsn/0j/7RP/qBsn/0j/7RP/ruUPqn4GgcmbkKQghXIpEeFIoA0D+H/aNvblS5PzO3aF/YrtCfHnQUDSEEIlJKy9w6iCh3bfmXOqoH57ycrzPG+vekxe4SKFD07vykV+pI7VhboETEfgy1VMcOPzimhWp6i8TjcdM0gZDW1tZlHyyNxxKdXZ2xWCxrDyGhjHo9nlCoQtfVaccfP7BuECFEYYrH68mR+YiYI8b7R/8oc5cSQqLRKOecAuzbu2/lipXJZLK7szOWSCAQQgglBAnB1HbVVNXj9YbDYZ/Pe/oZZ2i6hoQwynSPnnkA0zv2cB7Mfo2y79osQggAyNwKS9/7oLmleXfDruVLP+zs6kSByHmku1sI5IILIYBkIh1KG4YxxgC8Xi9VVQoQ9AdOmn7SmDGjVU2bOGXKkKFDMuU2pMYnYZJfnz8/EU9QSp3PABCCKXe+IAQI4UIEA4GZs87v36VCCEpZ5n5p+Lhh7do1hMCGdfWrVq1OJOIAYBhGPBoViFwIFHIWD86tvBgFoJQCYwpQr9/HKOWIXq936LBhZ51zNkWiauopp50arqjIu4FDrmZaAKVULhr3NzYfaFaZQglBgtw1nAIhFIhAUvAbDAgQ4L0N1XDw+oCpf/LUj6TvDVKLJM8AABCCIr1oWR4TMnrMGE3TDptwzgTHrVu27t2798Vnn0uaxsfbd3RGIoqqenUd5GcAFGngOGwURCREcC5fIIpEImkmk6qiDqmrC1VWjBo3dvaFF9bV1VXVVKfv4RiGS8E5ZeytN96868d3qKqKOevtCJRICAFich4Oh5/8v39U19QQRPLJ08Q555nwtG3L1g319R8sXdrW1tba0rp3716CRNVUXdflZygAS23UbGGeLdtT6qL0MhFCBCI3zVg8TpAojI0YOcLv8QwdMfLKa69SmTJ2wni7WzrkQMk5Z4z95le//t+//z1cUUG5EARN12BGCaFAeCGgREJUIJQAR+S9DZRSpWcANHUEDEQkhKWAUnqVGSFICCeE9aAqGtjzCCLjcsj5X//x5PCRI3Ig7BDZL/InIpHI/NfmbVi/Ydn770fjcUVRCKLX62WMISIXwr0tADk4AEABgFJENJJJ0zCQECNpjBo9asqkSaefffa0E4/3+Xw593NMHXLTBEqfeOzxl158qbq6inOTkIMyNefoWqAoImOsta3tS1/58qdu/TQ3TaZ8UoKi0iOX3hL79+2b/9r8zZs3r1m5ykwmBQVCiKqqmqYBAAqR78HLn94CSg8AAWBS60eMx+OccySEc+5RtRmnnzqkbsg1N1xbWVmpKMqh27S2C6zreigY9AcCgvNM/auX572YWSvhsukb1t190ZN3PAAATX6owQKFICkre83qNa/MeWnVqtWdnR2GYQRDoVAwKJ9ICGGapvXpdZyNnM0uEIkQhBBFURRVJYT4/LB///4dO3a8sWBBdVXV7AsvPH/2BUOHDT3UgvqIHHWmKM1Nze8seicQ8CeTyRJMGkRkAOvr1yeTSeUTg5JpI5dz/vbCt9et/WjBm29Fo1EkGPD7VU3t2WyInHOwkdZQ7PlFJIiGEPKdHgjuuSIueWcxAZg796VxE8afd845J06fPmzE8ENhEikOW0F6EyRClwCRLoH1ELlI0f6f7tEZCOEAyPkhPbdCCGmVrF2z9pl//Xv16tWxWMzn8/l8PrkphYuTnPlQBR/w4EZEJNhjeqqqqus6F6K1re3Jv//9lZdeOu/8mRdffvmo0aPSdsaxAZQAsGP79o7OjqA/kJOzgimrCB1nWAjhCwSWvv/Bls1bJk+ZfKhNjT4CkZTSaDS66O2357zw4rYtW4UQ/kAgEPCTVD6Gw8ZD18cWslE1B14FImQch2AoRBBNztevq1+57MPaAQNOmjHj2uuvm3DchHz995AAJbG3RNwf174wnPHa0s7KegREYPQQOaHk/mOMbaiv//e/nlr6/vtCCK/XGwyFkPO0iEovhMNagM3rgh/OBE3BOSFEVRQtFIrG4y88/8Lr816/4KILP/WZWyurKo8ZS5xz/q9//osSmnMa8w0RhymVvvh5r7w6ecrkT4KtnUwm57362qsvv7J582ZN04KBAJFS3Co7Eko1HyEDKy0vBdnLJHcsBfDous/ni8XjC956651Fi846++wbbrpx/ITxANAr2qXSu6Yx9D1kxGIwJee7Pf/EQ7P/hKCMdXd1zX3xpX//7/91xWPBQECip8jQYcFml5S/ZHYiBBGRc8aYPxBAxKefenrNqlU33HLz7IsuPNpVS3nz6z76aOvmLT6vJ61NF5w3SwWTMbZ506bWlpbKqiqpqB6rtvb6+vrHH31s+9ZtTFHC4bA0NLHI4w8lYQhaHdJ8TQ4RuWkqjKl+v0Bc8NZb7y5efPY5Z19z7XUTJ08keTHS3vNRajoCTe+k3toCWEjaFPUi5+uYrasL17+V5ZTM+SSAQE56NTLfk7TI2JbNW5547LFVq1ZXVVWFgkHL/Oecu4VCSFfsSoGdgyLlhq+qrtq1d+/PfvrAa6+8+rVvfH3CxOPk+0cjLgAAIm7dsrWrq6uysoLbCCQ3ViEK4fF6t2zdum3rthmnVKX9J8cYSiYTyd/+5jdvvfFmMpkMBINps4OU5HMsVpyDo2cJ8k5H2jAPhUJCiLfefOuD95eec+45t33rP7xebznedluITSQTBEVPBqnVk2ORDloH5wXaeCUcXljKeSi0NpYS6TCrw9IQMA3jmSf/9xtf+drmLVtra2ul/9t53qBUv4+dfoT2ulLm+5xzXVXD4fDatWt/+N3vPfm3J6Uh474ire8MeU5emvOS1+ct9v7zrXKBSCl9b8mSnHTXY2BITFm5fMV3b//vl16cQwF8Xq/gHEVmPogrp5Cd48L9RrWzAjHvzfQayGS4cChECL76yiu3f+vbr782nzFW8r6lLm80/znBxqfj/BpsLmWJCGCvbBcEEeLip9Ex5tPzFUToPQg1TZNSunf3nm//53/98S9/CQT8Xl3n7gLZvajTOm+7/OWQekQgGDQ4/8uf/3z/Pfclk0lKqeBHE1bKE7Jl4+bW5gMy3cphYsGFmwKF8Hq8Cxcs3NXQIHXVY8MpaZomY2z+a/Pu/NEdGzZsqAiHZcZFQTRwkL6H2ttmeZw555SQinB45/btjzz88J//8MeWlhZKaQmlq67EIJYqKw5RYMflZbGQ5giFlErs1TsXQiiKsm3zltv/87+2bNkSCAZJquba2Qq2u7eS/UGQ/WiYt90tf0Vwziitqqp688037vrxnQ0NDZRRPIr0SkTO+dw5czojnQpjaL8N3O9YRWGRzsiy95eRVGDhaEdJAFAU5blnnv35zx5kCvP7/WlYcW84wiGW9M5XztnbnHPd6/X6fP/3j//9n2/f3vBxA2OsWL2SOk2Z42P3HB4XRxGKjMOWYw25QRZ08aMH7xwAy17idOhwzgsvfv9732/r7PD7fDJBldjI4YKw6DxjopDcsgwsoqPkSLvMqyorV61Y8a2v3/buosVQknw+IhBAGevq6l6+YqXP7+epc1LQqigY6lEUunz5h7FYjDJ2VCuVEiW7u7t//fivfv/b3wUCAQog0b9XbB2XoR4oFRMcFCAUAoWorKras2fPd2//7+efeY5Smi7+KQsoDyZ2lup5pKm/CndCoFcMSYc3ad4vCnsL66Ayj0gZKydwkQ59/PG3f3ji8cfjsbjP6+UZHnF0IZCc3a+W64rZQID2Ug2LXAjOud/v54I/eP8Db77+JmOs72OllFXr1q49cCDL7i5oVTgrmyiE1+tbu2ZNR3v7UW19y3zezs7On9x517NPP+MPBAAgM4HXjVlZwsOj1UZFR3sOi8HfTK3INE2/zxft6vrNr5749a9+Ld3KLpeM2h8GwbE4UEcXli+6e7wyBVc+COa/AzaGdk5AHAAEL70eXZ5PAPj147/+97/+FQgGFYUJK494/g04mP/oqGmijW5YWg6m5bdMzpmiEIU+8tDDb73xVgm2zOEfADDvlVfzi0ZIMenQFvsZwDSMN+e/flQb3TJqP+eFF5d+sLS6pgZ5bqZHOQFbZ8PIMgXFIRPOLoCOjkZnuraNKUq4Ivzs00//4oEHZVjSzel2AEoTipQQUOime8s1WXAxwMqStcyvRAczM8NkK02jTFvcv3zoFy8891w4HEKBliIs30vo0pEK9o9fplvDGUSAEBSCUapo6kMPPrj47XdoH7bBpaxq+PjjnTt2eDxayWLP7twKQj5cvjxdXXr0oSTnjLEXn3/hr//vL1VVVaZhuFTWMM/fXYLvEqw2Pxa/RcEdzCEi57y6quqVV1+9/yf3RTo73eiV1EH8liBD8h8V7bV0LB4BexFVCzoB07XewuSllQMTQiilv37siZfnvhwMB4UQBFHY4Hg5T42lzlK5PiZECqDr+s8feODDD5b1Wb1SpmTt2La9oaHBo3uweF3J+eIBv3/j+o2rV66iR4nHNseRQhl78/U3fv34r0LBIHfPQ25VSON+j+VjIrooMCtNxKHV8fQF/EsXv7d37z43SqXb9CCX/oLSoErkoSr2nivETb4C2pucQAhCKcsjIePJv/7t+eefC1eEMZVJU6yvGqzWAmzsCztRVI5QKTDtiIxSk/M///GPkjm4D/rpZCr4yy+/4s2I4VrujdLPoeAL33yTEMLY0ZRQKS3u7Vu3PfaLX/r8/sNpAkKhycci1cZi9gNNxBO6oj7668cnHDfBTT04dQnDUF5g2o1oAtcgAo5oWEK9Cjg6E2jxzy7330dr1vzjb3+XhduWZktpMwnuUv9IkUX6aC8jnUFECOHz+bZu23b/vfdxLvomN35nZ+eOHdtVpjjLqhI0IyktFE376KP6RCLRN+p4ixjRaOz//fFPhmkwSkv3xTvuHOLur1ASJmKRWidlLB5PaLr28C8fGTthvCSrLvgrtCB+OetflvEpdHfs0eqgliPewbUC7/IAyKg3KdJHKXXJnTt23HfPfbrXa6liwSE4T1jGmQdHLdXunUzzLRwKvbdkyW9+9QQt47wdEtPSNAkhc55/ofVAi6KpZaI42AClpmn79+9btGAhKbsVz+GcGUrpC888u+idxYFAoBy3Cbh4XdCicsjnJY58Je6PEmMsHo97df2hRx4eM36ce+IC6oSSNimEYFXFAVZGq7PqBIVqbKCM7VuQNMjNAZC8oVhM1Fuq8ZTSh372846ODk1RRK+GDhw+aWfLgOvro2uPhCVWVoTDL8+du/LD5X2naAcRGWPdXV3vv/e+5tGJTXlJmclqsl8M5/yjtR8ZhnFUqJQoBFOUzes3vPjMM1VVlS4jUeh6H5Ywk+Bu0xYssQNHlAyFQz9/9JfjJkwoit7FKeG8h/a+PAWn5BwrdHwfS/q6XeqM028VGfWWhuc/n/zH5k2bggE/L0NKu68JS8edejrkMCbvmaZuuzRnZdHedERN0x68/4Hm5mYA0hcCO1J/3Ldv/7Zt23TdYye0Cj64MxcJECI4DwQC7y9Z0t3dfVRknsuSlb8/+Y/WzohigxdukMvl2ZR0gowxmhrp7kxAs4b8TFE2HBQi1pJUT9FYLBAM/vzhh8aOG1ssCZZDwrkuACxZc7BIB4FlZkDB2Xe2+sGFLkBtvk5dWKlQUtRbQsOO7Tue/PuT/kDAlK3pemNbgz0yQmpvCSEM04x0dnZ2dEQ6O03T7GlPxpjCmEtKvoJqpkO6kkDUNa2lve3pfz8FfYYkAgBefP55WfZb8nK4cWtQSiPd3Uvf/6DvdzCVjrk1q1Z/uGxZKBTk2YRAlocUnQ0vO3wBkJszFot1dnR0dnR2dXVFo9FoNJpMJg3DSCQSsWg0Fo12d3d3dXV1RSKdHR2xaFRu3TRoQobIdxlAz9clw8HQTx98YOSoUSVQBdrSrJnczO+ahBlRF3QnirH4yS1H5QErhdw9xZMlA5t74SZX9G//7y9cCKAUswOszpODLp7oINYDMMYSiQTnnHNumqaqqn6/P+jzjRs3Vmo027ZsjUVj3bFoPBYjBDRNpUBVTVUUhds7E9JKAXUkE8m5n4NN3DgPBoPPP/vc9OnTTzvjdNnG68iiZEdH5/Zt2xTGyufKw+y8t3yJy01z0YKFF11ycR8HSgkTzzz1tJ0KCY4WmIMiCRk/wTmPJxKJRIIxNmnSpOraGhRYO2BAdU01BRg6bJjP5+vs6Ni/fz9jrPVAazQW7Y5FjUSirbWtoaEhFo3F4zFFVaUqqmpaDjeC3cmCfJSMxYPh0M8e+vnoMaNLI1RVHGQOIZij0IKjIglWR6ig9xBLyiS343fCUr2ctp93veMlf9+7ixcvW7bM5/ORbI8+LTQ5LkmhKaVASDwej8VidXV1oVB46vHTTjvjNEVRA4GAz+cbPGSw/OT+fftj0Wg0Go3FYt3R7rkvvtTW1nqg+UBzc3M4HFYUxUHxAfuaH8s3cx5EU9Un//K3E086SdXUI8hoyzlnlG7esGFT/fpwVVUJMRaH7UTzth8i+ny+bVu2bN+2bdTo0X22P4S8sZXLV6xZs8br9UhaILCxuEmRPNBSV+Cct7e1eb2+4yYed90N1/v9gYmTJ3k8Hpd3aBhGw8cN0Wh3PJ54790l69et64x0Nu5vVBTF6/XKaKGDKMoyKxmLxmIVFRUPPvzQyFEjS6adVpyUI5u6IveWcq7TU65TkUQ4+V5bKDL9CoqhDsWMrCDMMKgLezEoTSSTf/7Dn0iKINbyzovdfJkrQimNRrtNk0+ZNvXUU08957xzhwwdmn8M5E8PqhuU+f65551HCFnx4fJ19fULXn9jz549uqZ5PB6Dc1KoH4ZL2sH0DXi93s1bNi9Z/O75s2dJG+pIqZMEYOmyZaCq+ctBXdeTOG/FzB2uKEpTc/OSxe+OGj2673onhSCULl26NNrdXVVVZVnTSYoh0k/rkoxSznk0Gq2oqPz0Z66eMnXKqWecnq172ZtoGSukquqYsWPk65NPOZkQsm/fvvcWL1m7du3qlau6u7plI1y51R36HjLG4rFYZUXFAw/9vByUJA7tav/0+z8+9c9/hsJhOY+ipD4YMmrMOff5fD+6844hQ4cIgZSCG0B083OuKMpdfNFRaQWCoqqqyrklqeCCMvrsU0//7re/C4dCmU6f8isIgRCgVHAejUWnTp167fXXn3zqKWn5LOkM0psvrcWg6InHSZ0uU7vpaO94Ze7c1+fNb2jYFQ4HBbpSnMGKmc1y9ihALJEYOWLEw4/90u/3H8EW4S0tLV/5/BdNw4A809t98ztwBxYyUSRpGIOHDPnzX/9fH0VJRABob2u/7evf7OhoV3ov7kQpjScSmqpecumlN9x8U3VNNUnz5CNCMfGZtMIoc0gOfhFJ84HmOc+98M7bb+/es8fn82maZmcoMMZisVi4ouKBnz9YssXtQqNMpQeBu9Oe39IW09naiIyxQXWDampryTE6kKCRND5au7ZXXLE5E8sYS8Tjmq5ff8MNX/3G1yXkpXntId1aPuenKeRTDgshUGC4Ivypz9x68WWXvfLSnCf/9qTH41EUJUdxzvdPob0zK+dhBaLP6920adMHS96fffGFR6TNjvzRdxa+3RmJBK2SBNGddumga1uYq4iqojTu279s6bJTTj2lD1rfEoAWLVy4f/++UDCYb3eXIEsIIUBpIpmU+tD0GdOJZOcEKK31Qr5kTTcrra2t/fLXv3rVtde8MX/+yy+9vH/fvlAoCJTmdOJjjMXi8XBFxYO/eGjkyJHl70BHPkoksjG8nUJBHDs19vjggBic11RV6R6PkD2JjsJR0NhkjG3dvPm9d98LZaiTvTJUxuLRaE1N7S8efeTrt31TctnL9MAStiCllClM8gJUVVV+5vOf/9Gdd/p8vmg0yrKPNNpggQOIZO4QIYTH53v+2efSoYPDDAcUIBaLrVq1CqzcNcSm0gldPGMB1YOxzs6O1atWycPdB4U6ACxbuoylNg84xg9c+QEpjcditbW1jzz26PQZ003TlFQyvSgk0tqA3Lq1A2o/9Zlbn/jdbz7z+c9xgdHuqPwrpBSLWFz6JX/eKyjpBJSKqgrImhBhBYu57I0W+wxkcYvM1YKjcxT2hRHy7DPPEUYL2rAOPWry/0QZ6+7uHj5q1IO/eGjsuHEyq6PkBkk5205K6ZmzZv7uz3+cMmVKRyTiHKEuqFyI7MiGrqrbtm97e8FCctjZvxERKO3s7Fz6wVK/349WelPJHSCcl9IUIhQKvbtocUdnJ1OUPhX+lnZ3Z0dnW1ubZbJnQYaLfFIrSmkikRg0aNA9990r/YCKohw6T0vm1q2uqf7Cl794xz13Tpg0MRKJSFxWpMUdrvjpgz8rLROoOKDM3zkFi2ccMxyPiX4i9iMajW7fvk2hFEmBvpV2qg3k6TiM0lgsNmr06Pt+et/gIYN73YCVmMs5r6qq+unPHzzh+OOj3d1pLcB9grGttgWAiK+8/EoinoAjUdf41utvYl4oqShuFywJjRRF2bdv75J33iWueWEPz5C+7NUrVq6vr/f5fIhoB/duJgRTLg6v1/uju+4YNXr0YfOxyK0r+fZPPe20Xz7+6AWzL4xEunryJSsrH/zFQ+X7JV0BpWEYBLEcet2sJAM8ZqFSanmLF72zY8cOr8+LAomVr7Yo802iZHcsVjeo7t77fzJg4MBD1w1V5rt5vJ4f33Vn0B80TdMyuReLJ+tHIfw+3/r6+rb2tsMZzJF6U1tb24I333Q5aS5rkJy7fmbteYDly5dL53Vf27GCYMEEDJe8f5TRzs7Oz33h8+MnTJAtyQ6zD4EpimxF9f0f/+CmW26ORCLhcPjBh3rN4i4MlGU1P8iCS8SMSpJjDygBwDTNj3d+zAAsZUEJvavkNcPh8J333DVw0CAZtzl0j8AYE5xX1VR/53v/w01TplxgNqUTuKARsnwQI5F87ulnD6duJfWmbVu37d75scfrzQ9Sub35YvA0y1BA1D362tWrt2/dxqAPcXRKo/WVua/4PB7n4lo31jelNBqNnnPeeZdcdplEqyPyUFK1FEJ85etfve9nD9x57z1lZgKVZnqXYoVBljoJQAilQI6Vfp45you0Xue/+povELD0xGHxU0oZ7erquv6mG0ePHXN4BDVlTAhx5tln3vq5z0aynZVYhsUKhBCC27dtTyaTh231pVD54L33TMiyYyyZPS0tSvc9LNGqlzIiaqrW1NS8detWAn3L+jZNc8/e3YwpRTlVrN8HME1+5dVXybKCI6usUEqRkNNOP23S5Eky1NnLm8phNwABdJ0iYFu2gaiqatP+xtaW1r5GwNUrSEkIqf9oXdJI2Cl9xfbGoIxFOiJnn3fuNddew01+2AS1jKdfdc3VEydOjMXjOY9TlIGWfp8LEQgE6teuXV+//rD1IJPZ/kuXLtO1rK4PDhFtcDSo88HCgYWhp6Ee54GA/6U5cw7FoS3/zGMZtDJpaRSPxkaOGDF27Bg3xLeHY91T1RaHwnIt0K7WpWfRoSgYgJimWVVZGQoFj2A126Gy8hAJIe8seifaHWM2e6UoFlIghHOu6tott9yiqirQwzddcmn8gcBt//WfRjJJbFaqaBYogIRp7Ny54/CsvlTq35j/elNjo6JasE+671tQMFDuxIyFqKrqzq3b3n93CSF9gkhJ3sOKD5d3dHQqSuHKdygEoFzw2RdeVFFZ2XfOdfkJIUUDJWOKREo7vwzaU2NkzzUgoqLrqqbhsRjPEUJEY90EbCUw2FRegg1cJePx6TOmT5w86fALakopN/nYcePOPOuszs5Oy1+HYonThfB4PHPnzM2pDjp0zhAhxIb1GxKJhBRdYO9DwCKRAuyXOP/BGWPd0ejuhl1EVg32ATcRIWTn9u3RaKwcJRcytss5M8/FYzyfpRBQUkYxZX07nH8XwhlJqgH5MaZOohCMsQPNzZvrN3i9XrQPGlhOF1rVC8uKgmuuvQ6tiFIOh15JQdO0mz91i9frzfT3o33DuAKHSlLndnTukpBxKM8VCmSKcqCpedGCheFQSGqXWCTwuUcKZ2pqFELT9eUrlsfz/BhH0E3UFekS3HT/jA6wqymKYRjHZIS2CKBMJpOyZWAJBle+3iSOxeQg+UQdbe379+1XUrQLaK+/WAqbLNouSmOx2Njx44cOG0oyqrYPs1JJCJk4edKwYcMyU4WIVR9gl1E+RVUPtLQs+2ApOcSZ51Iqz583r6srApSW347KOW0on+c/xy3j8/mWr1hRv24d9BnvPAK4yV5Aew4USRFkGsaAAQPCFWFyjGazuAVK+fDUdTvK/O2VOv8gFSV27EVyCCGEtHd2JlEUSwtkjZsA8Xh8zJgxAwYOOIKkO5Kt8rzzZ3ZHutI2miUNl0vEpISYgre0tsiNdahv/qOPPnI4uy63IKZgpTT9ID0UoG+8/obUdvuUgAcXwX2w71FjCBGurNA1jXzCTW/MM7hISXBJEJmitLa0Sp/XsYeVK5Z9qPSS6id5umpra4+sd1z+9NnnnjN8xPB4Im53J+5bowgh/D7fig+WRSIRdsjaJMhs0y0bNq7/qN7r89k5Lorq6IJClLMMApGp6tbNW9ra2oD2lfQ4KIbtws7sSERjk6dM8fp8LrsYHrNASRBptoMSMhpwF3vwhGkedY3hXQJK4/7G0jZKflRBCOH1eK686sojyEtGUhm8gwcPHjBoIDe4ZN+Q8USaepE/aEYHlJwXQIiqqk0HDkSj0UO6HIi4rr6+K4/gw9kvZCe0KIDX5+MusBLtrozo9Xi2bd26+O1FpG+UM+ZbA8X6nXsEgKIcOHCAZztnPolAqTAFoSeWm6ldljArgnOfz+fxeI5J07v1QDMAYCEQdLkMCKCoap8w0BAnT56SSMRj8XgikYjFYolEIp56kT/iqRfpD8TTLxKJZDLZFek8pMJS4vKrr7zq83ldoptdI3igNB6LnX/h7PMvmNXd3Q1WKaXOPNDpIyOF3zsLFx2eoL8b8Zxz/1C8sYiIXq++sX59Z2fnUdFJrfxhm8wso94pprQyCGgBOOeBYNDr9R57eZSIyFPMNHaqiuu6JjC5WV1drelaX1CWAeDiSy9Z/uGHXq9XCKFpmmEYQgiPrhuGkW5nmMsjBaCqajKZJAC6qiaSyfQFTdPUtEP1aJL5ce3qNW0tLQpjaSvXoaEKtc+XlHd7/Q3XCyHmznkpx4pH15qpDPoritLw8c4d23eMGj2qLxwB7I19z5jS1taeSCRJqrj+EwqUMurdGzEKBACDm+KYSw/qART7lLR8BuycijeROrGCEMYgGU1MnDQpTetyxL0Kg+oGPf6bJwBAMlRLas50xxKw3BTQU+EjoVYIkfExlCzxh2IbyPYGK5avONDaOqC21jDNfC4rlw1IgNJ4PDZp8hSP11tZWVlZWdnW2srcrbL1GVPV5paWpR98MGr0KME5O0I10b0LtbLQe8+u3QMHDfxEm96ZTrKS++RkfvIY086lFN2xfXtzU5OqWte6QqEMksz8SgpgJJITJoxjjAneJ4QKpVRVVUVRZCc8RVHUjBeKqlj8T1EYY/JbPS8O/lU9RA8laWK7urqWvPtuMBjk2c0vi35qgGh3bPLUyZWVlZzzK66+qru7mzFmFwUq2FtGCKF7PO8veS/a1XXEDVXnX7eTJdZESgLnz5v3SfdRZtlTrqfP6n1ARMoUdmz5MqQ5tmfP3o6ODpUxWSrnkNLsqrQWQNoyfUoekDTHe/YLayr4VKuT9Av3RPFl3STA+0ve27l9u6zvLpYRLlNBME1eURk+99zzCBLG2LhxY/2BgBAiM1WoKJoYRPR4PJs2bGxrbz+SsAJACNF1zaHlurBBB4uNjchUdeOmja2trUDgmHdT0kKKoKt3c7w22UyUqChKR3t7d1fXsZceFIvFTMOUWxDyOomji0nL/DdjVPd4+5pvgaRD8NkvrKng5VRkvHBPFF+Wdk/Ie0uWSAgoZ4dJYoVAIDhpymQCRAgx7fjjR4wYHovHaZH3D9mqhhDi+WeeI0c69h0OVyiKIuzbFLuU7gJR9+i7Gna9+PwLQEH0yaYXhwkoAYhsLlbQs5NvV2a1M6Q0mUgkk8ljb/qS8Tg3zUwRDY6aODqedlXTwuFwcU6NT/yQYZyPd+7cuGGjrnvQhm0aXCwB6SG4i1x+xRWIQh5+xti0adOIEC7pOG3JfQF37NiRTCSPFFBKQTVs+DCv14NcWJJaoc0U2dVoBgOBOS+82N7ezhg7trGSOnhq0rXedpoRutNFhRBeXe8jWS+9O7gQ3DUPPBRK3GOK4vN5ySejJqx31cmdO3bu2bNH122JV/LLUSwqEQG4ED6/f8LECZnWz8WXXUYyeJwKFrRYork/EFi7du2a1asZZUckp1gmJ5140okVoZDJOabMoBzlBhw9SDl9zBmlyUTiR9/7gSwnEfyYxUqn5mKYosQpp5slAHDTDFVUyJahx2Dgu9iDbfVFIMTg3O/3Dxk6pB8oixqMMQIw94U5fr9fcI4uVCG7ww8A8e7oqNGjTjjxRNl7QyaxV1ZWTpo8KRaL0WzTvjgyYyQA8NprrxEgRzChkgthCrTsd28pQsDRJBKIute7ZcuWO374487OTsqorH/9BAFlIpEgKArCgBv2IJkexI9FlMxvzwSuLZesDwBw0wxXhIePGNEPlMXOf1tbW8PuXYwxtPH/uN+9gpDjjz/+YIc1ACFEKByaMnVqIpmEDGe0nRQEG3WVIGqqtmn9hu6uriO1vrJGduyYsWkCIWd3JFjt7RyERc4DgcD6dfU/+O73d+7YIaWLJND9RAClc++6YhuPADk2j76maSLVYcbhcLrJP6cpfuZ++HM/JBfRnBdebGpq0vKStGwxy+YdmR54yWWX5vigCCHnnnt2ZShsZqdnujRR0yCl6WpzY+PbC94mhBwR61uadLMvvjAWO8gzXSyxdH45k+A8GAzs2Lbttq998/FHHt29a5eskhKpcSwDpeXCW8ofLLD5ZHoQPcZC3rJscfeuXaqqiAw3pXsCEcxBSSv51D+c9SOmKJHOzkVvLQj4/c4sGAW1S0ppPBabPHlSRUUFioxSE0oJIWMnTBg0uM7kPRkO6DrxK9upRzghGzasT6aU0yM0cURhikM3eQeVCG2wVeaKKiqbO2fOt2/7zz/85re7Pm6gqYGI3ORpq/xoxAHqRnqQvHCYQzvvvJxqZIxFu6PxePzYQwGf14cCLQmW3LfQIOVUiH7isXLfvn37MvhAC25mtFM5AYxk8vgTTwyGQgIPuonSnVjOv/CC7u4oZQysUsFc3a0QgUDg7YVvR2PRI6I3yNj0jFNPnjx1Snd3N6UUCnUJtetBb6ESCUGQhMLhhGE89e+n/uc7t99/z71bt2zZvWsXADCFSas8rQ0gIk+Nvg+dbqupHJKE0MZNk5ailLFIR0d3d3d1Tc0xE89BREqIL+AXKCz1QMxu9GrXOaMfIssxJBljL77wIucm2BPN2kn0HM2Im2YwHD535nnEijIZACZMmBAOh7lpEpA9mEtZOAAwksm331p49bXXHKkSaa/XGwqH3bddE8U8KeecAVRUVHR3dy9etHjRond8Pt/ZZ54ZCgZr6+pOO+P0yqpKgkRRVUVhmYWhlgbBkaXRcgWU0AP8hZEerLZd5p+5aVZWV4dCoWOpeF5qBPv27lUUJWfPgf20gDvZ0z/cCCoAaG1p3bFtu6IoktwcHJX3/AblmQcyaSRHDRs2cuRIQkhOGTulVAgxZerUUaNGbdywwetYjI+OhI/yT2/Omz/7oguPIE3MOeecvXTJey7ri0rI6+CcyzpXQggXYt78+YJzVdP++Y9/UEWhlNZUVU2dNm302DGAxB8Kjho9auCgQXbImwOaR2TGbIFS03SekR4kCslqtJXVgIiqpsr+15CxCQ9RATgQwGIuLD9fGgtWd1d3fltXLDVnqD+SU5Q6SSn9eMeOTfXrK2qqeSrMgoU666KVZwkojccTF11ycY9OZEWBAQDTpk3dsH49uMg6yvmV9F0JIbw+35Zt23bu2Dl5ymS73zp0QyY8nXbmmcNHjGhs3M9U1YGi3I2ebrufU0WrQEgwFJL7O5FIiHicENLR3r5x40YZHNM8nroBA2sG1BpCDKgdMGLk8NPOOEO2uQ6HwxWVFfkyUhqmhzPLyhYoE8kEoMh3XRf0++TQVvbMNRKf368c/bwpmRtOILa0tEiaAwceeDfygBIChOia1o+A7jV6AFj49ttM1zLburkXVFl55qZZEa6YMOE4Z4XlgosuevrpZ0roH5VzRdM0lyxePGnypMOvHPXkNYeC58w89+9//WtYr8RU8qkdwRK4flK7T6YbJVFK05Wguq4DBYJECNHYcmDP/n1ISD0hhJC//+3vRKDHo9cOHDh12lRV03xe3/EnHD9x8iQg4PF6pHRJEwgcBgtdcWNWY6EuS8TeoiQEKYBhJD947wNFUXqeB4lhGpqqYW/olKZhKIpics4Y5Vyohfz6uUcOIGkYgwcPHjWmOLpASdwtUVLYbBp0cVAzGjn12mL3TeW0t3azXKbmxqZ3Fy3WdV3Y9L9EG1sn1wYHiCcS04+fOGHiBKmo2ilitbU106ZNW7N6td8+yF4QOxDRo2nvLn73q9/4+hGxIiljhJBTTzv12WeeFYK7qTiy7TJmc/DtPpyOeYP8/6kp1FRVaglZ6QRC7N+3b8f27QKRUfb8c895vB6P5jn5lJPHHzdhwIABJ82Ynp5AbnLK6KGbT1cqHrXJQXNzU0Kgpml7du3+6U/ug5QXXPoeiKKg6/o/h/UTEiKFoEARBbCDTkO5NtQRsJiitLe23nDzTd+6/duCC6Yw98c1nVhnJy3ciOi0At6LVZ7HdpqRZHV8Z+Hb7W1tFZUVdjmJdtR2+Ta4yfm1t9wo0dBWEePc5/dPmjx55YoVlmnB4C7dWBb1tx048M7Ct8+ZeZ7gnB4J6/u4SZPOOPOMBW++FQgGsVBSpyXwUfvapPw/UUf9NM0ulWPsq6qq6zqmnJWxaCzaHX3ppZeSzyYrKiqGDRs6evTYy6+8vK6uLlQRTvs0pbVx+IDSuY9zURmqjGVFuFDm8faS2iMXXgOQikaxV2WMqbpG1aLdAphqPlVcn2vL66Ss714ZiXicc5G5VUrpdOTCeih2vpjCdF0vX52UfX1XrlqlaqodwZ1LWS7zoqsqKoYMGVrQ2CeEzJx1/osvvMBNkzr2/3C+E0ppa1fXpk2bzjr3nCOl+wshvn7bN+vX1be1tqqqKopUWcCRpja9pUU2HQnYYytYqheIB4M5hDBKAUBTVUqpYZpbtmzdsmXrK3PnjpswYdLkSbNmXzB5ymSJM3aWQe8DJfTkVGM6klNaIotdmCJd0NILIR1ETFcTFr/teoi7i/oiIgFAIcyMZBE38gas3oeUx9PnC5DyiPXl/njkZw+9v/SDUCDAuZB970uojaCEUACOKHWBMqsrKKWRrq7TTjvtrnvvLj+CAZRGurpWLF/h8/mEfXscN2lYlNLWtrbLr7iibnCdmxsbMXLE4CGDd+7YWVSn1pyf5pxXVFS8Pv/162+6sbKy8vDHvtM17FdedeUffvd7j8eDpunSh+ASBwrq1+iCLVRYdUuniKYQFMDn8xFCwA8NDR9v3rxp3muvnXjSSeece84ZZ54RCoelb6S34FJxAh8kQEC44HAuLTEQU3NBylOmsKRfd+Nvddhocg2o9B5kqLEWxbDudPBe1CuSRrI7GgVKRZ7Ciy5iTZhNvZ7pMRCuv54rdCmNRaPJRKIXFFOBwGDe3FfyYzgOm9PunAshfF7v8SccXzAcIK1vxtjs2bOfeOxxr9fLHcHFYX4IIYzS9vb2RQsXXX3t1UckSUiq0ldcfdUb8+Y37Nrls2/wa+d/zNwnOea2ZQszdHRAOW/O/OscJIcmxKNpXo9HCLHyw+XvLVkycuTIy6+4/PqbbuxRO3rD+W8Lt5qui2xdyS46Aa5N8nJMeJdIB8XYCKXjFKI8Y8IwwLUPAYu883LOAKNUobJwlCqp10rea5b6X/5naOq/LPsdl1/P+Uz6CuUbD0ChtbX1nUWLgFGSIZ8sJxkcxRUQwjkPV1TMvOB8qai68fyOnzAhXFHhslOr5f1Iag1EXLF8+SHlfnd+FgDweDw/vOvOcChkFt+eO0eIuqephkIpXMTFhzFbzZTlPV6ft6qysrGx8fe/+/0dP/zx6pWrAUASMB8qoDQMg6TSg9y4rsD1bOKhwQhwp/D21i6TGqWiqjmmsvveA1hIApW+qIqCVnOe81/nf+b8Kb8NtJuv51yh/GeUCXR7du1uaNhl2QAZXMghzDC8Y/H4qaedSoG6Uet6Ms+nTR0xckROSS66o2rFDL3Y5/OtXrVqy+YtjB0ZhkqpVI4eM/pb/317V2fnoUhLPBQSwEEhFUJwzjVNCwQDH7z//g+///0HfnJ/NBqVSdyHBCgdfOSWSOSS/xmKNMzRNRo6f9EZW4EQVuqaFWSEdpl+0YtDZMTiRUkX7/X93VuySh7m+fPmCxQOwUYoZGSQVHDATBrHn3CCRED3t3HyKafkOFvAoYo8e7f0vEBUGOuKRLZs3oxHrq5XYvRpp5167fU3tLa2MUWBIhfO+bjR8tDQ8hAVDjMiIhfBQEDXtTdef/2OH/54965dZfbsog43Sh09bpn3XbApHdjMacmst1jIhwIu+3mVZ3rLBtZgpddgMVfuQepeM8EOBmRLC6ZDbwNcUTLSWQkyDGPlihWapmFeb3FLpQPtQTcWi40dN+aEk06UkXT3t3H2uedQygpuHrs8sINVOh7P3BfnQG84JcqRPUxRvvmt2y657JL2tjYqWwq73r1QSIMpip3IwXLFQq4/yDM+UGBFZWX9unVf/8rXXn35FdmuvZeBEmz4aEuGNrs5xWIWAAt5AErTYkq3CsvIA82x1Dghmkfvnb3vyHdQgspcPmj2iuktgyfzX33tQFOT7LaIpd6MfBzDNMeNn1BU3DmVeT7g+OOndUejkoCndIVOVZsOHNixfTs5cjUCkPIjff9HP7zw4ovaWtskaXxvGRbOHgl0vWTg7pjnfIZz7vN6AegjD/9i7rPPK4pSmg1OC6oABcmcnaV6mUYZutNAXXbywd4GSk3ViGvPNBaCIV6quMv9aYWVucst51zYr/7h0SilOrl92/Z05KHYXZcj7FGIiy+7tCiEkn49n983YdLEHiah4g3VtIGoqWrrgQOvvfIaHlGCWzmZQojv/+iHV19zTXtbu0C0kwFQ6Iihi71UGtpaGmpYSIsXQigUAsHgE48+OufZ50rzCFMHhbyohHN0vU2L+isUyfBIXBBtWeqnpVFmifKs5SxbDJH1Ui28zJuB8m7Mzqfh5rT0stqeghXKWDwaXfjmW8Fg0Lkap6BoB4BkMjl02LBhw4YWWykszeRZF8wKBIM5sg2L3IGmaQZDocVvL4pGo0e28X16Ev7r9m9/7gufp0Di8ThNMUgS1zIS3K0I9urOLHhxgQiI/srK3zzxm1fmzi0BK+2bizEFgTrz7jmnCkGR01SuulGe16yclcPiJyf/AwhgGEbv7HqBLvW+oty4JSvsvaJRShBZsXJVLBGnrvt320XVZG3PSdNPqqqu5sVnxhBChg0fPmzIEMskoaL2EqO0tb1t3bp1R7w8v0evRPG5L33h4V/+csiwoZHOzmK9t8R1OvqhGLkWQ/b+EYg+v+/Xj/7q/ffeL7a/rn1zsWRC8jxjQcZJd7ZtQWmARQJNUT/txvgtTXezywuBYhcYUesl9iCqsHS+nnDtPClH4GMxDpCSh2Ek57z4oplR01ZQ6NrtNC6EV9NnzJhBiq+Ll5nnlNILL744GouXGYcBSg3DeGP+G9KoP+JYKRMAxk0Y//ivn/jSV75sGEZXdzcA2NUs9Ur6nV2KC7pwZBXx64hAKTL6p9//vrurixTjF3ZqLpZZYojuWshDke+XOd3QS58HQpSiTov8MICiKLLCvATDP3/CY9FY7yiUQhDXKa7F/om6UKt7PXdVAtP2Lds21W8IBAIiuybH5cHLnGojaQwfPfrUM04nhFCgJQAKIWTchAnhigrTXeY5sXGuoRA+n29Dff3u3XuKzVI6REOSUvv9/ltu/fQjjz161tlnJZNGpLOTgIzPUzcWVVGWSsFSfbTCRyzkQAOro+H1eD7e2fDgT39WVDeOwsGczNvKt1WxyG1BbDyyYG8ouYFXLBme0rkaxdZ6E4JCJA0Ds9ODwOFIOLgpEAmAyU3SK8Q/GQ9TrBqOrtfRYZ6pzRVK928AoMBVq1fHE3Hq2B/UzdIzRemKRC697JKePGQoEUomTp44duwY2SmsZGIURNQ0bd+ePcvf+4D0mSGD+0KIiZMn3f2Te+/76f3nzjzPNIyurq54PK4oLMexi8Xkw2HGDsl31jmDAHXvy7I7HJwHQ8FlS5etXL7CvWSiJTuwLDuQoAtfHjp1Iivg70MX1nQJuFAy6QNaFVO7MQBz5wqAIHo0nfRGmggozK7EuKAkt8sAdV4aLGbnlKbjAIXX57+uezxpFgy00SOcHS9AiJlM1tbWjhw1qhyxJJdp+ozphmG4uYqDK4lz7vH53lr41mFm7XZphiPi9FNm3HHP3Y889uh5M88bNnx4a0tbMpEwOaesp2UYODJjWUSi7dHNslFC2rQVxfCW2e5zREVlDz3487bWVpcnzimPkgIImz3vHKEuM7utoMvJLrJWmpcTStpE8vTqHk9OCp5LfhDIS8KXjrNe2eL5nlNSKDHYjYMP3MnLXh9S5q9YvqKl+YBs3o0u9hvanRZKY4nEkKGDpx4/rYRIRc44d+bMyqpqh7pvV+UGiIqi7N69e319PeljpMvpDt2IeNykiT+++65Hf/X4D378wwkTJ/q83s6OjtbWVpmtBSnDnGYfB0tXIxTSLfLRM78Cyn0WDVpo8XpTU9Nrr77m0gB3KmEkSKjNEaAlYTkU76coyv3kDFK9nkQJAKqqCvtLgYsYMaSOCgWIxrp7y/R2L9uKNWBLVh5LjnqjEIi47qOP2tpac7qJlOguRzzznHKJIKXZXje47pRTT45EIpaAa2k8WZoXiqq0tratXfMRyWic0NfgEhEF5/6A/6JLL3n0icef+N1vvvL1r33285+rqqiIx+LxeLwrEunu7pZcf4wxCZrpQWxCi0X17SgNhSw3lc/rnfvinMZ9+92E0WwT9xRFRSCWGmVac7YjVnJJh15aLw4oxmZ3+XNQalFqzmEr2LTWQVr25ra2ysd0zjRw7xEG+76SblTpEmaYMdbdHV3w5luhUMiyBC2fUjtT5RT5EhToGWeeUQLHc76kBIDJk6cufGuhpTVgKbktjU3BRcDvf+v1N666+iqv19M3+5UCADCGiCiQMjpw0KCbP3ULIeSqa6+JxWIfrVn73pIl8Vh85/btbe0dpmmoisIUhVJKACiAoiiUAiWAqQZh7neLJUselrHTBKKm64379i98a8FNn/5UwSOoONya6OlQaBvTxCJ1k3xFuqAQRncY6tDdzCUWl2z0FgwWYV5rb9vK9F6yuZCbvXU2XOpEdo5OWn4NJSJQ+t6SJXv27AkFAnZ4ZNd4IOf+gdJIpOuMs86sHTCgfBJsiWWzL5r9pz/8wRScWUGbMzPjQa8RoqZpDTt3Lnv/g3NnzTyCNBnu4FLq5T1gV11dTQgZOnToJZddSgjZumVLS0uLaZpbNm7euGFje0d7NBpNJhKRzs5EIikjlpqmeTweClRyRWbFhRx559y4g9CeFSVzOYRpegP+efPm3fSpW6QB7jDntkBpGAakCpmx0NYsmJEHeRDmvhjRPckFsWLxyNSCwd4BQctDE/cuP7AXG/FY76QHQUqjLIGYuiAGuRRg1IpSD0sCSkLIksWLMTsNq4QVkQ1IEHHsmNEej6dXmM0kP+YZZ53x5utvWHYcK6LIEoAjLlu27NxZM4+KxsXp5Mp0cwHp8x07btzYceMIIWeedZbU3Qhi0/7GTRs3Nh9o6erqpEC3bd22vn59LBaVaMs5l451SqnX66WMQTrLrZipyOGcpjYkPumWDQpjB5qbV65cedL0k0oEynQepbOpiDbER/nyE1JaNyk1rbKgo9cZEZiD/6XkbkRWpBg5lmD69oQViGeKAbOXTHDTNHqc6xn1Am5S1SDvvyS7E2+OACu5SsetfSQEY2x3w6716zf4fV5i40hC10quYZqhivBlV15JeqNJgMw8V1X1hBNPfOWll4PBoDNJuHDew0J4PPrq1av37tk7eMjgXu/6ckgRk2RohTLyQwihMr4DQAAGDa4bNLguU8C0HGhJGkkgsGfP7mUfLGtubORCxGOxzZs2Rzo7UQhN1wFA1zUgwFOpwWDP15N/rAp+jDHW3tG5+J13ps+Y7uymVBw2ugN3sfPxAytITcQSdl4JtGInytQNaZH04OjID5jT5EBlrKurO55MlqBIarqGeVCSyZVLs2fSWQXrLVsLBOGmaZqmlNLEkQvKNpUVCEEiHUzFQmHJ/mhLle2Nea+3NDeHKipE8fXdOepkIpkcP2FCRWUF6aVGldJkmz5jxqgxo5saGzPJ3xzOp/UpQNQ0be+evQ0NH9cNrjsqlEq7ObFcx4M2NSJTlJraGvmnusF1M04+Of3J9evWd3V3NTc1vfryK93dXfv37eec+/1+GXIB+3Ci+1guZjDd+Xy+9evqm5uaa2prHJRKp+Zi8oiIUrfmQV8AoqprN958c1VVleh7zhcKNJ5IjBk7Rqq9Lr8l26ccf9JJC95c4A8EMK/FlQN3rOVv9GJBhjcQqK6q9vkDmCck0aZfq9WtIlAa7e5OJBPOS4Yues9hKtxcwpFbuWKFruvoLnfKKSWL0lgsdsHsCyQnAuuNJrEyIlRdUz1o0KB9e/eSvO4pDtHOfPUHETVde+WluaedfvrRok4W4dnMdkTmvO5RQimdNGWSfP+yKy4XQrwx741Fby9cs2aNkUwG/H6eapVTpkMp/dMej7558+a2ttbaAbUO6KQ4G0/owoRCe70SCQEKRjw5ePDg62683uPxHI3C0GEwd6iP9px1vVvtJ+//m9+6zTS/JtsblHwpLoTC2J/+8MdXX345bK/NkULduzKRVC+mcbkU781Nzc0tzZQxdOcntbsNSRdUV1c3ceJE0qt9z+UkX3vD9UuXLvUD8FKjnSBpzxVl8+Ytba1tlVWVfTP23YvWev7rtOWezsq86NKLZl88e8WHy5/791PLV63yeb2ZfBbg6GkBd8unadqihW+PGz++FNObUoZAsFDcxu5UZHwLEFH3eJLJpMIUAqRvrn2JRREZyc8FJZhlEeeh4BIPBoO9dSnd48np+FwQ7sF+ipVimImlg/LluS/v37e/uro6nRgEGTTADg5iyFvfpGEMHz585OhR5eeZ52+ewYMHV1fXJBNxoBRKkk9ICCBqutbY2PTy3Jc/89lb5QyQT9jIWRqp+5986ikzTjll0YIFv3zkkWQyqWuaZf5DfgNRl+rIunXrnNPFHGnWCAEEh7RwdFUk09M1AQhhCuuzo7STI/I89G7SpBxUoV7xTGFvDNM0EdHSeC82ZxiKN71l+mQsGn337bd9gQDnHB19Uul3HCpKUYjzL5jV610PZeb50GFDTz/j9K6uLmazkdzk+SIhyIXf513y9qJ4PH5kGSr7yJCiQgiBKM6bdf79Dzyga1rCSFrqWy47xeb8SWEs0hlpbWl1wEonmjXZE9fB1oYysuqPHSPC5mQWm8jJU/UPveUP6pXh7OIpaomBgN/rly9cYuXOHTv37t2nyubpLn7UrsGnDE+HwxUnnnjSoTNoampqmKLknLRiuQgQUVXV3Xt27961ux8lM6WRFEjTTjj+vgcf0HRdCOGeXt5hHgWipmmN+/dv2bK5FKDs6aRhE0HGDJXKedemvo7HKkq6Z0NwChMjaqra0tKyacNG0seqfV16YF1lubp+LOlWf3nu3IRh2Cn7btwd6WMWjUanTJ1cVVOVk3ZT8lRnfrGH83z2BVqeSViUayUN64lE4vX58/sCQ2Vf0y5N05w8ZcrNN98Syeuv6yA4HWORSCnt7o62tjgRZFDn442u3aL2TUGBICqKQo9FOwJdJ9uT7KBnfooDozQRi7e0tPQpoISSlt7y7hUKFeGQG8yQvvz2tvYtW7bqmloQXwtOluBc1z2XXXGljHdnDqlsFjvSWqocQgjTNOvq6s4997x4NErtOW5dritTlPr69W1tbeXXWR5jQ1EUbvKrr73mzLPP7u7udvaYueUZAkBRwG3tyB5EwH0BtZ3ehIhUUdrb2ru7uopiyjxqLILsrQyF1sm2whJAcB6LxvsaULrBI7TqqJPzpkmI7nOV9iAEAsCypUu3bNzk83p5Ng+xy/OQqU2YnAdDwZNPPZlSqqpqpm9aNqspdpBUkCE9FEVhCjvjzNMTySS1d1m4ETyp5L51uxsa+pVKy3nUPfr5s2ZJ8hdnRsuCuxd7HOK0taWF2KdDKA5SHQmCPaOcQ4fyIvD4KB/BYKjHXVI2vQUAJBLJzo62oj1bh3JwxPwSIzeKNs2OTQtEjSnTpk0jLlJzGANCYNGCtz0enQt0w+SGjiE1SqlhGHf9+I40+VCaBuVAU3PNgFrhukCWEUIJdHV1Iee+cEhgj6MMkQCQ5qbmzI5j4GgPOtAdSE/lW28umHr88cdYQmWvGOCEkOmnzKgbMOBAe5uiqphdbF0Um6KsidI8+ofLPpRF38UBpa7pACB/GfI0BeK6jhgAhGmGKiv8gYDow6X+pQ1VVWSUszQmpCxZAoQLEUsk+pqlI4PEUIhek2Sn5uS7hxBIzcABbnx/ALB3z56t27dRVSUo3MxhTsEY5nn9jGRyybtLMq14eSAUVTPr60UxiwWESLZa0zSRgPS/AwEkqKqqx+NJC5fS0mZlmbOm6e8ufuemW26qGzz4GE6oLG0IIcLh8MVXXfHnP/yxQtdN+yRfdNcQm1Ha1RlJJpMejzV1ky1QmtwUUqW0cbqBoyGZcX9IAEzTFCX1uuvLRjchZOiwYZWVFR2dnYqiuAlVFAjMIemt/mK9YN8AmKbZ0d7OFAWwB64KtipF+48JRDdtJgUXTGHvvbtk39691TXVwuTu5xAcHyccCvYkKWUDM/F5XSrLmM3zJPdzztWcLWUoVP6b/quqq60trR8u+/DKq6+Sc9KPj1n2LuJxEycKPChIwTExCJ2Zp4HGY1FSQh4lF5wQpHkoie58WDns05Qca/JQetmHjxheVVNj5BFcl9AwEhF1XduwfgPnnLIj7MyVKdmtra319fU+jyfdg8c9Cz/mXVGV1IQFf5fReCy+7MMPfV6vc9lisRPEueiJvXAuOMdUHEak3iw4REb0Rn7PTF2t538ubtg50xYyBIuiKCuWLzcM44jvhz54+gBAURSf1yuEgDz5Z1ena7frCJBYIuGwfA7BHLCkaAXXxyOTduFYdUcjIrGpEHDSRm00KVXXNm/c1N3dfcRVb3ksY9Foa0urkpEbiK4xK1tuAEfh9wU0VXNzBiKRyEer13g8HhToYC4VrBcq2Q3i3iwoqt+vm5L/TOvS6/WuWrmqK9LVb3dbOPSEGDVq5JhxYxPxeD5FQ1HpzGCTi+IKKItqq0bs3ajS2c0YBXoMSkUAkNx5bk5LeorsQgcKY50d7UbS6CNP17i/kXMT3DXjdRIMAGbSGD1qpNfndd4DUqTPfXFOugsNOtorOah3KOpBi1JpLVPBSnbIUErjsdgrc+eSoy219vDYc4FgsLqmJmkYcgaLwqtirRPqjLLuN5x9Mh3KdN9EInFMCsZQKGzZ6tauy7AdgydJ1eckiyd8O0TjvUXv0OxGrFjkUScpfrNYLDbphGler9fBVS3t/QPNB95bvFhRVSywr6xDJTn5v71is7t5drtulO7Z4C3KkwGEEOvXrZflpP34mL9hTNNMJ2OBk7pWoqxyB5QARVXUWPK7IBJKabw7mojHj7HsWfksZ513jqUrzbJmCR01cUppMh5/5eWXe70eubSxe88entNKoSRDVZ55s5AAkEkRu3fvavi4Qfd4sFCJi3MWCLqglsGSHofk8faXo8OijfcACOGcB4PBlStXbtywUabK94Njjl4JNny9xTYuLF2jxJ7/g2L3UD7aGoZRM6A2XFFx7KUHEUJGjxqFjo2lMo8udXZ4AXDTbN7feGQliizy27Rx47adOz26XtBB6UaiaKpWVVklH5LYW5qEkDdfnY+Mkuz8zWI3t0sGiqJ67bokGC2oxrq57axEfW7Oe/U10huU7Mfe0BgDzM0go647sLrf2LZTr2s6z2AhLdlaAYIy0YQfW+lBmbCiaJqw5g8p7rSgELrXu2nz5n1798ne80dMU0ZSv259W0uroiolK7eYQv9kMjlgQO3Z551DCGGUOSgIiURi7bq1kgWDWinddlZtjjMeir/PkvZ2zwvhQnmxq91Aq9OIWTJGXV+/zjCM/pBOjpem5UDLnt17VF2HQkQkBdLyAAiiqmkOosiJPQjwID9H2fHBY3CR5cYNV1bWVtdw0yz4iA6Vdphafq/Hs2P79t27d5Mj5r9HxlgymXzx+Rf8Ab9MYyxz9RFR0fSKykqHnSTtyrcXLNy7d7/u0fPR2dmYwjL6hueviBsFBLKb4uZjorU7y8brQmwYAAiiput7du95b9Hi9Cwdagzq+/4xFAgAe/fu3b17t65pQqCz2HOuf5UZ/tUVFbJwy1IgUffmRql7zpr//dgASs75wIEDph4/NRqLFeQycTDM0//kQni93pdfmFMikXDZg5uCEDJ/3rx9e/doxRCSE3u6OUSsrKx0Xn0gILhYv359TlocFs9UVu6yFknDnP/Twp1RD4X+mXbvJpPGR/XrTNOEQxzPl0Upfb/AXMZOTMPoyuPFgJIsDIHoC/gdaJIpKW8Xors9B5TCMephAQCPx2tnahXlKJEUx5quL1+5YkP9egLkMO9Xme8diUSef+qZnBqh0tJcZCvteCIx+8JZDsdP/m7j/v0L33gzFApyzqFIzlPi+kiUZp7nW9zgaOg5axhuhOhB2OU8EAoueGtBMpE8pJnnMoQQj8VaW1qOoOfHzZDg+Pbbbyt53dxKsDAoY8l4YvqMGQ5P7YqkyM0L+w2BlNJkPJaIH4PpQTI1YeYFs/w+X7qrDNrrCAVNACSEMZZMJJ76578AD3dIp4cF8qWXPt69S0+RfbheaOvTjogKUwYPGepgUsgfeu3VV+PxuEP6pHvUPnR80s50MFgMFLq8MSCEAUS7uz9c9uGhM8tkBK+5qfkH3/3+V7/0lQ316ymlvA+nJQkhln+4XFVVZ6ZklzaxyXm4ooKUwEcpA9aCIJSxyYAQRMIY62rvlAUnx1o6GAAhZMKE8V6Px0z1rYXyDjDnPBAIvP/e+ytXrMjso3TIjW7OGWPr6+v/8ue/hEJBbvO7RbFDAUAiHh85auTQYcNsO9Vgz8c2bdxEwLYWzb1pTDKIi5wtayxjmYr9Ymn82ySViMo5f/mll+Lx+KFDyZbW1vvuumd9/fpEPP6j7//wg/feZ4rSBz1mMiw8/7V5jfv365qWU6BNrea2gGQSwuPRvV4nDkDqYIURlJwotkuLLvarDHrW1g2qqq469tKDpDnJFOXiyy/rjkQoU9zTCDlKF1Q19f6f3L9967a0wnWo5TNjLNIZeeKxx5miSLpl5zt3lYgOkDTNMWPH1NTW2K2+EJxS+vHOnatWrvT7/Za9m4lNa0OHOwR7Fb6cxCNSTKFawXlzCw1C+P3+DfX1e/bs6XWjWKJkR3vH/Xffs2njRn/AryhK0kzed9fdb82bL1FJ9JkUTkQEAvv37Xv6n/9SNU1kozg69lyw26KGaVZVVw8bPoLYcwDaAqWm6QLArp8cFFF1gADAuYnHYhIlSbXBGjpsGKU0vTpY3tkQiJqqdnVFfvvEb2QjnUMq1QUXlNKurq6777hz8+bNPo8n8yjaASIU8uKl52fWBRcQhzRAAERctvRDnrFDLOu43dsxxEU4BUuS/aQQTzCxqrEhZeM1pTSWSCx9/4Pe3QkSJdvb2u+759516+r9wYCk9lCZwjTtoZ89eP9d97S3t1PGJBPIET9upmlSRp/829937PzY4/HkiHOwyV8uAJTJZHVV5egxo3PahLgCSpObMghPiiTCzDszQAhBAHKMktrLVnnnzTxv5KhRsVhM1udDnvcq5xQVjIdyIfx+35o1q3/z6OOHNBApyYo6Ozvv+sGPPvroo3AoLNn9LG/eDa0DZGRQJuLxSZMmTZ46xakRKKUAsHDhAk1Vc54RbWYMXaRtF5RS1B5ecxbLTVDO/Sy5L0iHbPNQVZQli9/txXQIiQudHR33/+Qna9as8QcC6fQjRKQA3mDw/Q8++ObXvvHqy68wRmWHgiOY3muapqqqzz/1zJtvvFlRWSFSBMlFCTbLjXHyqac5X4Q6TKJ7kVjwFuFYT5bVNG3C+AlCHGxe6+AjcykuBBeBYPCpZ5751aOPyfYgvZtGJ7nCGGP79u69+4c/XvfRukAgICPObveu406glMZisTPOPMPn89mVeMsnWrl8RdP+Ji0VwXQTmHb/J7tzIlygrXueSnTHKmSndRY8Voioadru3btXr1rVK96YNEr+5O5716xaHQgEMu1rGYVDIbw+X3tb2+OPPnbHD35Uv65ewjQics4Pp94jPQCKojz39DO/fuIJr9dLSpoByON4lhc/9/zzSgTKEragzaqjrGI0j9HKHJLydl99/bUigxuZFlkhZ4OVvLq6es6cOd+57VubNm6SsR0hRDl7VGYUy3NCKX35pbn/8dWvb9y0SZpdbgzDgpUPmLKSKiorzzz7LEKIZb8tGd4xTfONefOj0W7GWFHGdTkljM4bGBzpfxz6ibt3tkCRoSQkRFHVttbW+nX15eeEy9U/0Nx89x13rVmzJhAMZgrIrHiXEJqqer3eDz744H++c/tP771v3dqPAEByvJe/Gwvu1bQ4b2xsfPyXj/3hd78PhsP5ZYsut4EF9b1pDhg4yKN7iGOTEsXRaZq7ZsK+IsK2EwgShbGOtvbuSKTiGC33lj7E2traMaNGNTQ06B6PyNAtnRllMJujIf9PgvNwMNSwq+HOH/74a9/8+vmzzpcZqZzzYvuAy20ns2oBYFfDrpfmzHn+mWf9fr8n2y9ZFCxaHnVKaSQSufSyy4ePGOHQyQAAEvHE8g8/9Pv96bMKxZBF5n9SnuFUGxuLR4A8hRGt3swUeHYpQWh/WUJkRAwIoqUpgFbajeXGSEvNYCj05utvXnf99R6vp+T+ED0x7paWn973048++iiYgZJgRR2LiAQxGAgIxAULFrz33nvTp8+YOWvmiSed2FNtRYjgHDMayveKCpmxlOTddxY/+be/b9y4saaqSggUhbzPbjMoKY1GIrMvvLBucJ3M+igaKBVFSdfkuWmWQhybJVEAcuwa31K0VlZVXnvDDQ/9/Od6MYqkQ+Qh0zTwer3RWPSB+3/68ktzr7/xhuknz/B4POl9j6nOBOltmlY60n+SqCo9qrt37XrpxTkLFy5sOdAipZeDKQdW3GUFSXpQoO7RL7/qcnl7zEajBIAli96JdHVltppxue8tJ41S2tnZaRoGAZAFHEUBLpZnAeR+HQhBApQGg4F8+ADXG+Og9a0ou3fvWrxo0eyLLyoNKNMx7vvuvrd+3bpwMGhm6JJODgEhCCGhUIhzvnTpB4sWvT127NiRo0Zeetmlg4cMrRtcZ4l06QNy0AWXcc8oEMnBXUpSjcPSLxr379+2ddtT//rXRx/V6x69prqapxzopfXQzr/JQCBw3fXXkUI97xQHrEWbztTOWyR/O5imWVVdHQyFjuEeSdJxc/7sWS88//zHO3dKd5tDG6xihSEXQmEsFAyuX7/+7jvuPOH446edeMJ5M2cOGTY0B4Mk5OUrm0KIpsbGdxctXrt27YoVK4xkUtX0yooKZ79nfjgFbHqH5cxGV1fXRZdcMn7CBAdBLY/H0qUfJA3D6/NhRsZ+af4+ylh3JHLjTTcNHjokvdkgD+UtJYGzmklsyNnAxq2ZKQkiHZ1zXnyxOxplNtzV7pUjoJRz/uHy5RIoS0PJ9ra2+++9r76+PhgMmq693pjSHIEQn9fr9/v37t3b0NCweNE7gUDg/PNnhioqBg8Zcuppp3p9Pppq6mt5D5n7JL8o0zAMRFz41oJNGzcuWfxuW2srobQiHJK9N+xm3g3WW1gzyeSo4SMGDxlMCpEz2QJlMpnMbAJZXIQuY8f0dMuBHvv0GA7qCCEURbn+uuvuv/9+j8fjEBVxyO+zM8EgZQH5vF5CyLr6+lWrV7/04pyqmprLLr00VBn2eryBQGDsuLEer5cQ0tnR2dTUJDhva2uLxqLR7uirL7/S3NTU3tZGCHj9Pk1VMWUSFrQY8v0tkjJO2OTxCERN99x0y80O+086AXbu3LlqzVq/34+uq4Bsb5LSZCI+ctToWz/3WZ/f16f2xpZtWxe+tcBSLKEjMRLkTZrP51uzavXe3XsGDx2CAvO7IBTUJe+/977Vq1dLi7vkrQ5C6Jrm0XUkxOT8uedeACC6xxMOhXw+X1Vl1czZs3x+HyJ6vT6vx+vx6IyxUWNGpzsGE0L27tkTiUSMpNHR2ZFIJCjA0veW1q9bZwje1toai8XCoZA/ECB5bCBo0867IEFJpggECmYyee0N1wFjzna3E1ACACNgxwrlstof+lCH6kM+pFV71sxzz1q0aNnSpdLpli/r0m4glz1XwUoge71en8+XSCR2NzQ8/thjXAivrns9noFDBodCIUJIR2tra1uHELyrqzueiAOA1+tljMlth0IIR33Ect2plXqVc8NIiMpYa1vb1ddeO2ToEME5dVQnd2zb0XrgQFVVld2hRRdtFeRnKEA0Ghs/cYLP70skEpkH8kiKTy6YwqZNm7Zk8buZcw4pMVMcIxyipmmN+xs3b9pcN2SwzL4uBiXb77vn3tVr1uTEuJ3PsrDanIIQSLl3KCGVlRXS7unq6uqMRPbt27di5Qr5vJqmeTVd01SgdGBdnc/vSzuP9+7eE4/FDNPs7u5OmiYlRNM0TVUJgEfXvV4vWvVrg2JMMbQR/JTSeDQ2euzYs847l9i4hlwBZabuUJqoT52lVHfPT0BvYkTUdf1r3/zGyhUrTM4pZNW3uFHPsySe/arL3cMoZYxJZ6UM1Hy8Y6dhciBEVRWFMQTw+Lx+vw8JQSEww/DJBD6w959knmd0oQRRgEQyOXTokJtuuYk6dkmSW/O5p5/xer356ZNgZVI5nw3Oud/nm3X+LERUVbWP0NxKH8jsC2f/5U9/Rs7d+/3tnlRw7vF4Xnju+fNmzXSZtNJjcbe23X/vfWvWrg0GgqIYi9sywpZjQablXFo+ScsGCAgUiCJhmoSQLVu2CC7SBX+arsn5CQaDADTltOzxWqK97HTWu90YwfJxbrrlZhnGLAhNTjPNs9vVkiLVQ1H8V44BTyXnfMjQId/4j9ui0aj08zpPYE52tJuMIsyGZtlAFYUgAB6PJxjwBwJ+XdOAMUopEUL2WZWWO7pLfEHHDZfPEQcZTrR4LP5f3/nOoLo6B6pmiYwfLl3WsHNHfitzNxYJ5vWo4EJUVFZOOX5qbwVee1F8arp+6umnRePxTPguKpcoS8YorLm5qamxibgoxD4YvfnJT9asWRPIyCp3g5LFVpchopD5Zz3dfU0UApAwShmlXq83EPAH/H5/wC9rJSVQCiE4N+U2dkh+cvYOu48EMMbaOzvPm3X++RfMMk3TjUylBUG36G2Rc69IVEVpbWnp7OyEY7Q4JwcrCSGXX3nF1KlTI5FIjkpP3TkBnefWUsmSUrin4bSMg6eEcwlrWjCWYonvTFHa2tquvvaak2bMcHb6yMOwYcOGzq4ultEON//nqDs5TRUl0tk5++KLZKpp3wFKSVqqqurUqdPisRhltGRXbCbs7t27b/5r80ihzHOZqdrc1HTXD3+0ds1af8Av8lznaLWgJE8EEtdMTpb6HabTd2VL9NQuLSon1M5jXqwmJzgPBgKf/sytJCPOXipQIso4DBRJnmptMB4NtMm9dTDk9v3eD78/cODAZEbvSSyPGYG4Ll8lJbGToX00yVmekxQ7XKSz84zTT/vabd8AcGr5ILOFkonEm/NfDwQPmoGZO81Bt0UrKBece73eMWPH9MHGMtJ5Pf3kGSOGD0/zyLlXf6xsPe73+95euNA0THlxBy9wa0vLA/fet2HDhkAgYNfcCUtiGnY676WhhLsJwSKFeu5yUNrW3n7djTcMGzbMvUy13VWqqomeHmeFXc5OnUCAcM4rKyr8gQB+AtyUaaysGzz4znvuMk0z/U75xEIFNwSU9K1M9QFL+jqlNJlMVlVVf+22b6qy0ywUUIs2b9rUfOAAYyyzL5MD/wVkuFbzZzwWj48cNerMM8+yJXM70vthyNAhtbUDuMlJGd0fexQiRFVR9u3fv2njxgK88QC/eOgXa9Z+FAyHHfySUBIqlbbN3HyrKO4l95OJhCiMdUYi11x/3Wc//zkHCowigFKgIATtaNYKGnRwMIkEEJFqaj7F5jHvrBx/3HFf/upXI11d7pWIMnupl2LKFa8X5FrHACbnhMD3fvSDESNHFtx/UozPnzc/kUiwPDeuMymRtWsVAIWYOm2a+1yZw++mRMSrrrsmkUhQWspd5jw1ZSwRjb4+b54zWwoiXnrppaFQOJHXqgQK6TrWa1eqKHVjsKO7j5Vw22ldMhaPD6qr+9JXvuw+YaAAUJqmSdwVVObYbnkaChIZzTpGadYcDC5CyA0333jrrbdGIl2ZzinnjUjK2G0lS/J8n6NLLUMeVNMwvv/jH06fMV0WVhb0mjXub9y0YVNRvXAhr4sOZNwECrzgwtmkD/dlAoAxY8dUVVenSQ9czjBa6zGoezwbNmxqamy0yy6Qv3LWuWfffe/dfr8/nkhk+uOwkKS0BAhaEgOxSz+mQ+e1okwoO4oWwzB0j+euu+8OSOuW9gZQysAhdXfMCp4u/GRFv7O0py985Us333Jza2ubdRlfHkIV3IXo2iopVshBkZeSJLKGad55z91nn3N2waxdKTIJIU3792/ZtNmTkRgELg5SzjbD1D3EYrGJE48bMGBAn/XtSAtj6LBhJ5xwQiQSkbIEXR8rq2kUHq9386ZNTU1OsW8ZSjpxxkl3/uTeqqrKrrzoYkEvobDZqA7AhIUexw0XeDmraJECTKlhGEDIfT+9f/zECSX4Z6hLDdGNrED722aUAaWfHNP7oLAB4Jx/+etf/exnP9fZGcmvLLTrVOU+48GuoWNRKwV5AAQuDr9pmknD+OEdPz7jrDPdoCQhBCgAwJw5c3SvB/O6DKGLY5k/yUbSmDJ1amVVZV+mXAECADDthOM1XedWtJvFmhGCc92jz3nhRed0KJkGMGXqlCd++5uzzj2nta1NURQAQHdKmZvyZbB3H4GVzWQpFN2UFRScNEvjnVFqJJOM0vt+9sCUaVMLGj1FapQpzl33AG+XFsBkelBHB/1EYqVUu770tS9/+tZbOzs7nfO2esVZ7pJZ1s4l5AYuGWOJRIICu/uee84+9xyXKImIBEjDzo9XrVipakrB0+jmnjnnXp/3vAvO74NhnBwJQQiZdcEsLSN+VYL2lAlDuqquWrGqoaEBHH0OcgdWVVffcfddV115VVtrGzfNfO8w6Q3mOjfyvqiO7Q5w7EaZUBhLJBOKqt7/s5+ecNKJ3DRd5gO5Bcp0oXf5/i/I8Jh8Akean/wLX/ni7d/9bkVFOBqNskIFdiX0dLPjAy8HlNEGJbsiXZUVFXf95J7TzzrDJUpKRwQQWLV8RcuBA7qmZ57tItrV5ZiWpjlo0KBRo0f3/Q2GiKqqTT/5lHg8nhnSKbpTSOpyqq63tLSsXb2GFCLAl1hJKf3O9/77P7/9rWAoFI1G1bxNWGZfPJcbqbfWqeB1GGORSCTgD97/swemnnAC55yVWthqC5SKoggo0fGVVYIGkEyxB4lPWDwnX6+87IrLHnz44QE1tZHOzjTXXvk7I1/7wzL2sZO0B5Cbb/LkSff+9L7pJ093j5JS40skEu+8u9jj8+UwweTULLo8sZSxru7umbPOVxSF921maOmE0T36iTNOikXjlNF8hdplv+90tbW0vt9ZsDCZSBQ016S6LYS45vrrfvrQz0cOH9nW1uashjtTqZaPmOV8Eh1NDQogCfdmnHzyLx59ZMq0qcL1Ri0OKAlQ6VjB4k9dNmMVAiFccPykomSOU2/o8GEP/+rRE044oaurC/FgJk1pKf0u/YmkkLHjxt5hjJmm2dHRcdlllz/yxONjx48XXBS1+QCgo71jw/oNWnbfepG3c1wBNwA3zWAgMHHicX2tbNFOwUHEU04+ediwIfFYwjJpzE13ioMfRtQ1bcOGDR0dnW4Tpyk1TXPUqJE/f/Thz37uc4qqxmIxxhgUii+RVOG/+6iO5Ubqrew3yJsWzJDlCSMZiUSuu/66nz388+EjRwghaBko6QSUhpGUbg9arhgB2SKcfALqFwsORVEQcdCgQQ8/9stv/sdtRtKMx+NMYTmn3H27VFoSPrpv1EVSQUNKaUdHRygUuv27//3t797eY8qxIn5f2oYvPveC9Kxb3k9RHRQoIclEYvSYMSfNmNHHHZQkw/tUN2Tw4KFDTW6WaeGmg/7xePzF518grhvpKIoihKiorPz8l7/4m9//bvyECZ0dnYlYjDFGrSKNOfvNQeUvyhpw2J9FNd3MvLhk/Iy0d9QNqvvRnXd84z//Q1ZMlr83CqQHQaHMPjxkDohj2Azv6bFz3bV/+ttfph0/raX5QLpDQ8E5RCt3VT6/rPttCoXuVlFYLBaLRqPnzZz5yOOPXnbFFWlu4GIfPB6Pb9u+1eGnaTFbFiiNJxLX33Qj6cPpk/n+B0S8+tprjGTCDWeKy5ndtm2bZXGkg14peSvqBtc9/MtHvvejHwwfObK9rd1IJqVQdLZgiGPA0CHPDB2v45C/4cYdCUC6uruRkIsvu/SXv3r8/AtmpRtD9YKK49Lb6PxXu6mETxglZVGaheQZuu+Bn77x+htP/u3vLQcO+AMBCiCsyCwyYUI41idksl5CGQ4m6Vc1DKOtte3EGSd9+jOfOfmUk+Vtl+DrEUJQoOvr65cv+zAcDtv1kEmTv9kRYopsl184XDF02LCjbvXr6urCoYqePub2hCAFFSjJmRQMBpctXbppw8bjTzzBvfYEAMAYIuoe/cKLL7rgwtlvvfHmM/9+aseOHYxRn8/v3JkWXKiEJfiRHHjLrYmsAAAACXZ0dnp0/ZTTT/v0rbdOnDSRpGiTes0WdPMUWJoyknpGkJU5n4xC76I8VkIITdcvu+LyKVOnvPD8C2/Mm59MGj6vR1HVnHagdhSN4FrCOXwr5+IUgDIWj8cTiUTtgIE33nTT9Tfd4PX5ZAJaaR5xACBAXp37ipLNFWRn6IHVjeFB2nxCKW1rb5t5/qyRo0by8vz0h3PIzPNRY0afMP3ERW8vqrCRGS51F0x5KhVFeX3e/ONPPKHo8CBI+l2klM6+6MLzzp8579XXXp/3+ob19QpjHq+XUsqFyPeaYQZYu3FNOnCSZyoBDrZpjlMACEh/azweV5hy/qxZV197zeQpkwkhggug0LuuGKUQ0hXkN8jd0DSHuAmJqqrNzc2d7e2hT3Dg2+7YSG60ESNHfvv271x99dXPPfPM4sXvNh84EAwEJPtsUQcJ7ckcsdCuBQBGKec8nkjEY7FhI0acP+v8y6+8oqa2tmRFMnN0d3Vt37aNUWbXTcjhmOUwYkgeYo+mT548+ajbTlIJOmn6SR+8975TmbZrHRMRKWPr16/v7uouoQdGOg4m6eCuuOrKCy++6MOly+Y8/3z9+g2JWMzj9SqMUUWBDIJeO12vKKUKijc9ZcmGYRic83gsVlFZec4559z0qVvGTRif9mwU5TovFygp0MxESnTno83xtWPK7Ar6/Zqu9yOj5T5NM2WNHD3qv7//vSuvuWbTxo1znn9x166GRCIZDAbSCJVjlYNjHy50BJ2cQwKExBOJeDzu83qnTpt2yaWXHH/SiVVVVSTVF7cclJQgu+TdJTt27KyorLCkRHSpGqcfiiNSRbno0otL8Jb2BcfLzPPP/9Nvf495mecFa/jACih9Hs/OnTvfW7Jk9kUXlizS5Lc457qun3XO2Wedc/aqFSu3bt48//XXDzQf6GhvJ4QEAgFGado2lBsSisnedbYkrF1AGXVE3d3dhmFUV1dXVVVfe+P1Y0aPzoLIIhs49wJQKoqChEAKLN00F7NWzgFM0wyGQv5AoF+ddD48slvDuPHjxo0fd/Gllyx8a8HmTZveXrCwo6NDbgWv16uoCmJP79AeEHERxwBCMh0faXxMJBLJZJJSKjgfO37cjJNPPvnUU6Ydf3zasSiTLcp/OtM019fXq5qqMMZdnx+7ftyMsa6urtPPOENVjkpKKkRUVHX6Kacuff89vw3lOOaZosRe7WKM6aq6YV39zFmzaHkUSlJsS0fZidNPOnH6SdfeeMOWzZvff3dJZySy+J3FXZFIukG8rusHpbgQB++wpEWRhZWQ3q4AQEgymUwkEoSA1BPPPPPMIcOGXXr5ZQMHDZQ/bdd29DABpWEajFKqMOBOrT6dNzcQQihVVVUg9vF84D4Bl5RCqk+3oiizL7pw9kUXXn/jDbt37X7l5Vei3d1bN28+0NKiMEXVenrCAKWKzOqwT8oTiIQgN3kPvCIahmEaBgCMGDlywMCBw4YPv/TyywYMHBAIBNI6YG+FC6Wc72hvf/HZ54HCgebm3MQ3dy6FTIFNmdLe1nbyKSfrHv0oclCm4YBz7vF4pp8yfc6LL1YlDc5N4iJwaufJTf/zheee/8wXP19ZWVlmPCAtR3taMzF23MSJx02cSAi58ZabjaSxaOHCdevqu7u6dn3c0NHezoVglGq63rMnAWQxRY+xAuAM9FLUCUTDMNLvCCGSyaQQOHT40CFDhnh0z2lnnD5pyuThw4enLygh5fDYE7ZAGYvFWltaTM7TbVfRxkdL7Pe9rEiPRqMDBg6EVJvjfkAs7LiUAMcFEhw4aNDAQYOmnzyDELJxw4am/Y27GhpWrljZ1NyMKMyk0d7RyU2TCy6EyO89TSllisKAhsIhXdcR0evxTj95xqQpkwkhkyZPki7Inp1ncukF70XokSvuDwTue/ABIQTJ67VNbPSm/DBOxr5CQmDKlMlHnd2ducSnnX76o088Jrs5o70FapdzA3l4Qyj1+/2k98qFD1ZDIErzoq6ujhDymc9/jhCSTCY3b9zU3t7Guejs7Fzwxluy6yxB7OzslK2cBO/p+4B5EJF+TRVFoUxR1cqqSkIIEAiHK8IV4VNOO7WysnLM2DFDhg7N8uSYnDLaK7ZOEds433KRYfX333t/zYqVmteDjikCzoUEUqAIzoPB4OVXXRn4xJCc966Zll6jTFAwDAMA2lpbVy5f2RmJxGLRZDKZ2yABUdf1YDCsaeoJJ50wYOBARGSUZlYpHCQ6OxqKW/pH39yN8sBzwRHRNM3VK1ZGo7FoLBaLxZLxWCKRyNGoDuI+kGAw7NE9FVUVZ5x5Rtr8z9yKmSGvI7VL+6tljqYhrfLyzY10ityh9uxkKQJF5sG40XeOamR3TlQs2cN4mEFTAsihMIHlbu8jq2wLlLL0B3ojYRxTbot+pDukhy2f8AkzrLCjHVb6x9El0UlmuVQeyGA2Qf0hgtp+jbJ/9I/+0T8O36D9U9A/+kf/6B/9QNk/+kf/6B/9QNk/+kf/6B/9QNk/+kf/6B9HcBTXQSJd2+QyfppOHXB7fSHIMZrNh4jpUF+ZDygvBaVWqqXDdyXfRnobkKOtFVLPs5c0ez3VxFZFUL1yWJwXK3MczjnPvQHE3j2hsn2x7FFZxnFAKCNi7malnNKD8v+UTvFxmROXLrN3pdym8lcsf/poH5nZUeVkFKazKErLwstMwij5Nlh2vvpRtFjpOy9h9krb/GUut2VSXa9npB6pG8hMWSvtmmUeh/xdYYeVxaUHocB9+/d5dE9VdZWbz7e2tgohampqXF5/3759ClNqB9QeexpltDva2dlJKVVURbLylDyaGpuEEIPqBpX29cbGRoLE4/GEK8IlawH7G/criiK4GDho4FG0Cp2dnbFojBAcOKiU2du9e/fQ7HI6h9HR3t7dHa2trVU1teQblunMLS0tFCgiVlVX9VYNvvthmryttRUJAgHOzcqqKr33mMAa9+8nhPgDgTTPQNHHoalJ8NKPAyGkpaUlmUgMGjzYoczatoTx9dfmLXn3Xa/Pn8JpJAQibW379+xTPdqosWOwEJsBEPLxtm1CiFHjxhU4eASBQHd3176PGyhTho8ZzRSFEISjv68EEoIEKYH9e/Z0d0QkUA4bMxqL744il8Awkru27eBcDB013OvzF8NcjkjATCR279iJiB6vd/DIEcVOslypSFtb4979iqpwzoePGa1oWmmLVZQiWna7VAQCez5uSESjhJDBo0bqHo/L25ZOk66O9t0f7xo2coQ/FHL+IhJkBD7esTPe3V09cGBlbU0J8yO3TXtrKwpsOXAAALgQNbU1wFi4svIwnA751J0d7Wjy9gOt8p+cm+Hq6uqBA6CUJ8r5F8Sj3Xt2NhAAXyBQN2yofOQckma7PSAX1DCSu7bvMEw+fNQIj8/vfloyOLHx423bzESyckDtzbd+avrJJ1sa8hZAKelYfvXIo//4xz8qKys55+mzyBjTNQ0Ro/E4WJItZ7/j1XUAiMXjrhRgSiVrQzyROPZMb03TFMaQEESMu5sQa2sFQPd4gJBEIsGLtzXSX+dCJDMqcIsaCmM9bRQB4vG4KK8F/OFsFuLRdNknNpFIlGB667qeSCRcGomSgsxIJg3TLPmGFUUBQhRVBUQCYBgGIjG4edg0CFl2rSpKmvzMMM00zU85CgQQQin16DoSIjhPJJMltMMFAK+uE4B4IsGFKG1avB4PpSzSFfneD35wyeWXWvaQsA3meP3+ysrKcDhscn6QtDxV2lmRoXtbPp5k05MnOazrbqYgffGQrmMGnfUxMDD1eD2gqetQ/K46eCkhBCF+VS3J/y1JLwkjRCJmKY+T8SzBUAgO/exBLzWVlkSzSEig+NmTT+33+9O0iQWtZkKI4vN5y4h9pCnI5BUUVSVHIpiTqbgoqurz+UpejiyeJBlFIQRV1eP1Fux3YtnFRJJmBUo8Dj0rBQB+v1/XNVuJZftlwzBN0+RccC7yaETNFPca2HPBi9TrYt206c9zcmwOkcFcV7QITTXYEilm6dLPQG+45OVFSmsvXqxS2Vu6J0qC9JKuloYMdN2noddkbd9oNpk5A6Q3pJdETF7GimOK6ABLvQEq3cH206s4KbUZeRAOnapIXjcCdNHhtyg16hgbJTSDz1nU0hofH4YnKgcFXGnTReqYmTlMaeUokw8RCaHF5LodvKadjpN32IpIj7NKp7NM58o8Yuh4nw54bTk5buYzfdHeekzb35VNswEEIWB/hweZXwgRVh2ZnH8LXJwmxf32Rdeivnx8xE9Gf3C0aTfoPMluWngfHskEeeBVrGoMhR7EoSlVgY5UABTAMAyTcxRCtl4hlHp0nQuRPuQUiGmamUaP3YOoKeMu5/NZxxGJJJ9P+8tkMwM3miAAqKoqHZFp/yljTLq2LX/X8vHTPenMlG+058p5zkfDMEzTlL4YmakjgwS2bTIB0vegKEqOIy/ztu12l7xheYfpS0nuXpbnFmSMGknD5D2M1EAppVTXdSF4Kh2255rS9oXsZcpcysx70zSthNOhOMB+/irYnWcsA/XQXiH95AyHvggO3Nd4CO4BikHS0qSjZdyvNPjGPBHSA0+UCtPsisVqBw4cUDugpqbGMIym5qbu7q49u3b7AwFGqbSzTC6qKitDwRCikGBAUj1ggQASFIQwACFEY3OzaZpCiHBFRWUolIUmQAU3k6ZJAJr2749Go8FAwBRCcicPHTxE1bRUanWGdpN1BeAm39/UyDmvrakJ+AMoBKHQ2t7eFYkwxjjnlZWV4WAwK3SWcbfyn8I0m1tbY/F40OevqalGRAAaS8Sbm5tliy6Uj4PY2dlZWVk5aNCgmppaoNDc1NwV7d7TsEtRFV3XLSAPwDTNqorKcCgkCLa0tERjsfSzCCEGDBzg1T1A5LRlyo4eDmlKQBAkQJqaD8RjsYpQOFQRRiEYZc2tLbHubhlrlm0ROOednZHa2traAQNramuEyZuam7q7uhoaGoLBoFw++dtciKrKymAwSBAFIY2NjbliDHHgwEE+j46EcM73NzbmSALMaERaNFCCooBVGxbnU4F5LSiJ2/bfTu/kd1nJ7/5c8E805d2jKb9q5js5f+qtb7l/dnCcwzKtWnCNlQ4I5R5DHdaCFNmg3P3PpZeGURqLxYKh0E2f+tRFl1xcU3swjTcajb48Z+7T//53LBZTVZUy1n6g5T++9Z8XX3qJM/c+In7/9v+pr683ksaVn73qpk/dbPf595e8N+eFF1euWOHz+wli0jDu+dn9gwcPLvhQ7W3tX/vSl/c3Nt59309mnDzDNE1FUf75f//8w29/N6CmJhaLXXrF5bd8+lNO0yIQKNz14ztef23++Tef/9/f+67MYNm9e/dXPv9FqS1SSpPJJKXsmuuuvfTyy0aNHn3QdS7E/FfnPfXUU/v27PH7fGaqWVhK9YZoMvm1//jmmWefRQjZtHHjd7/z33IhGGPtHR3/8/3vnTvzPHkPzk9629e/uXL58ps/9albP/cZeYd//M3vnnv2WZ/fL9vvxBMJr9d762c/e/Gll2QmSMZj8ZfmzHnmX//ujkZ1XZcfjsXjl1915Y233Cwv9dN7739z/vyq6iojFYXmSG771n/IZipCiM/c8un2tjZFVdOCSkobREwkEvkuhbRRbzPppomOBgOW7X1zbzlCtrVFshHE5Z9y2gfnvAN5B7tXvuVm6qA3PJhoo98VBbXgQly5kXbO60Vs/NrFmt6W24lRGo/FRo8c+cRvf/3pz95aU1uTtkA55z6f78ZbbvrhXXeoqpbuCdoTWc7gP0477DJHT5/7VA8s+XlZmCQHN7kQ4vQzz3jgoQcvvOiiaHdU+vmRoECRLmHKPFWZPy0El+Arddue+0nFKDD/PlPolr4UFzytxJGMv6YPMgUwDcPn8/3s4Z/f9q3/HDV6NOdc/lFqYZdcfun9D/x04KBBiWQyXTQjDfNoNDph/PhTTjtV/sr4CRMGDBzITTNTDUNEU3BLV6CcokxFNfN3hwwdyoUgAAwgEY/XDRz42K8e//yXvjCoblD6K5xzj9dz48033XXfT3x+v2maaedy5np98ctfHDl6ZDyRYFKZBRCcJxJJklG9g/kQgYQCKIqS1tPdAiWRXtRS/ffoWi+w0yaw1J+GkuxTKPJXivpWvm+xoHWJLpRBsMKmzK8Xq41iIa8IsXkQdGcTFIt97jdS2qpNGsmKysoHH/nFoLo6aSkrimIaZjwel41YDcOYPn36D+/8cTwWY3kbXKKnbJQIGYNSKjhKsOk5TvL8UJr+DFOYdA5SSr/9P7efcNKJ8UQCkCBHClR+0jRNyDje8jWlFIXQdQ9NdXh3YxNAqsNl2siVN5ZMJq1rSwhBgoKLnz380JSpU2TzL5km2d3VxRijlJqGOXTY0J89/HNFUQ42U5Izgzh5ymRVVYH0TM75s86PdnVLFyoAJBOJnoxLTBnd6fh4qpJauiYzn1HealNTk3xlcu7z+R557NHhI0fI5aOUdnd3R6NRWWhoGMbUaVPv/sm9RtLIkbKUUiFE3ZDBt37u87F4AlJ9e+2ADLNRCB0babjyUUKhI0RKQhlnbQIcsbWg18wy8u4AzWhlDxZ8WIdvWQYf7OYQ7R/fpVKPxahp7iUHOtrg6EI4uVkju+gQsfeJWyI4UJqIJ2740k2hirA0XQkhzzz19LIPlkaj0QsunH3VNVfLIMb0GdNPPu20lcuXM3aw8p0xtnzZh/Neey1cUdG4b391TbUQCEAopfFY/OOGBk3TEomEaRppLeapf/5r69atXq9PcF47cMBpp58+4bgJ8qe/9KUvfusbt6kez68ee3zIkMHJZBKANjc2fus73x4ybKhUMP/8hz/u3rU7EAx0RbqCoRDn3LKwJHNaJHb83z/+d/OmzZRCRUVlpLPT5GY4XCEETyaSmzdu8vq8+cUIwFi0o/PSyy8bO25sutHr/NfmL3l38f59+08/4/Trb7wxEAwYhjFkyJDLrrj83//6dzgcEvxgWOmyK6886HlEnDlr1itzX+7o6FBUNRAI/Ov//rly5Spd1zraO4DCf93+nVAoJGf1maee3rpli6bpTGGN+/Y3NzWpmibw4B2GK8IECaU0Fo3edPPNlTXVnHO5fP/429/fXvi2qqgzLzj/2uuuVTXNNM2p06aee/7Mt958MxwKZW4AxpgQYtbsWa/Mnbvuo48Cfj8XglKaKdvsnF3gGPR38lGSlA4vinFXFRvMKSrqWvA2wF20tCh8L+ibg5IezS7FCrIn3E4wYCFLueQZzln0Ml2K4MJzahmwAnfrnnUziIqinDD9RLnjjaTxh9/97n+f/N/KqkoA+MVDD/v9vgsvvlhqYeeee+6K5csx+3Ktra1zXpxTXVNNMCv/lwJ4vF5VUYCAqhwMmy5a+PaatWt9Ph8ixmKxN19/41e//XVFRQUhJBgKVdfWRLq7165Zs/zDD6XqxCjbuWPnkGFDEZEx9u7idxsaGjRNkzpsMBi0JWXItljXrl37zsK3QxVhI2lIPUhwITl4QsGgnYlocn7CSSdKC1RRlBeee/6Rh37h9Xl1Xf/D7/5gGuZXvvE1GR8/97yZc158SYabCaXRaHTipEnVNdWZSmLd4Lqhw4c1r2iWUezGpqaGXbtQCKYo8Xj8c1/8QjgcFkIwxjZv3jznhRerqqpMw1RUxevNzcGPx+K0h1iLnjj9xLQr429/+etf/9//q6isQCSPP/Ko3+u7/Oorpao7ZeqUN15/3doSQvzqN772o+/9gJsmMMoNYdoXR2FGjMFh2PsoOQcsNx2yYKYLKfLsuQfo0izNkqPVzlgAhTwJUChSkQ/0YGXUlz976AKbwN5L4BCax+znhUJ5Ti4fLTMEbHAzFA7LBBFFURqbGue+OGfwkMG6ruu6HgqF/vV//2psbNy7Z2/j/sakkUyFdw9eQ1XVysrKyoqKYCBQWXFwBAIBaacLFPFkPA1YgUAgJEcwOGTw4P3793d2dkrUq66tHTVubCwW8/l84XA4FAyGQiGv15uZnuL3+wN+fzAQ8Pt84WDQLqMzfxL8fn+4oiIcClVVVYZDoXAoVFlZUREOBwMBawUCgHPu8/t8Pp80kE3TfPqf/66orAgEg4yxQXWDXpozZ+eOHU2NjY2NjZ2dHX6fV3AhLWIk5PwLLvD7/VKfTRP2XHX11T25O4QoihIIBILhsN/vDwQCmWasV9fD4XAwEAiHQz6vN/8xmaIIQkzTDIZDmu6Ry9fe3v7cs8/W1NaqTNFUtbKq8tlnn5VrRAg565yz6+rqkkYyJ1YNAEKI4yZOvOGmGyORCKVMtrZ3PsIFj4aT6Y0ESUlw5iaKDVaB0TKdaG4cXg6pSHZmoEu7j9iEei2BRhQyk9Gd287BqHcomurdAe4UZ2eDHWz0dPehdgoQjScmT55SU1sjLT5EpIoiOJfRDE1VW9vavvjZz6c6SoOmaYBZUc5kMtnW1qYwapo80xHp9XgAQCAqlOnawfpdgYLL6jUUsa64ruvyr5TS9rYDe3ft1nVdpAImhBAZ+8l0iXJxMM7jvlNpJBJpa20V3OT8YHRCVRTd42GpvMscoDQMs7a2duy4sT2+UURQKCIi5wRRIDJFue0bt5FU2g1ljFGKEr8CwYsuuUhqwdu3bdu7Z+8ZZ50JAOMmjB8wYGCkK0IB0kW6CJBDvscRBedCCKmkM8ZylIMDTU0qU+LJxIQJE+rq6iQcI6KiKD0lt4RwISQPkwTGyspKTddRYH5uOaWUm+Y111+3atWqNatWa6pmGmaZm7xAelBRShY6m0X23saSD7AlHDjrz+gOUjPPMy0mYdB9FAustC2X6OOMGuBo3pJDg5VYfBqmpWBH14ZI/gkxDWPAwAFer9cwegzS3NirEPKUWmjQAISQ4cOHX3fD9cFAQHDRw/wE0N0dXb50qSmEAmAKnmXHmUiBEqAKpd6w70tf+crAQQOljzIej+/bv9/j8aR1LuG40C61fnmfJ510ktfj9fm8qeA4ASBNTc1bt2xRbNBWcB4Kh6pratLhfoLZDh8hlHRoKJ0MBxBPJk855VSFKXIy35j/xto1a84652zDMGpqak446cR5r7xaUVmR9lSAi5QJzC7KHDt+vECBBlbX1ASCAdM0qQzFIKZzRVVVPdB8oP6jdZOnTpGPYOlSbG1pqaquBqAej+dzX/jCd9f9DxKkeRlL+dU5KES0uzsVnnENlMg5wQKriIUKFvPdcJhnP6ILBRCs/KSkUFpJ/p+EiwIY0kvfIu6AA8uQQ/n6F/ZG3iUU+Qh2ZgEW473FvH1SghACAGLyoowbyFAbCSGTp06ZPHVK3tlr/eryFYQnpBNNRgbk57/13dsT8YR8Ha4I1dTWSrWLEPLvf/5LpCpP3LuzRUGxTSkhxDKhctn7H9x9192aptkGQnmWPosu4oeU0lg8fu7Mc5nSE5H/4P33u7u7d+7YMXzECAC47obr3nnnHVkYgzbZYNTe3SQhe93atZQyE00wDxZNYfb2oDLRJ5nMFBiZ20bqof/6v39+4ctf8nq93OSTp0z+4pe++NgvHy1cjYM9xFo93twifJRCIClQeOXSg+lgSaHjGSioDTkYccIxPlBUMor7b6Gjcu3sFUVHC1S6nAv6GUpL58JCCo5zkqPLFEj3ThJRks7eY6BBEV90Kahi8bgsgkRCCAoZ9ZZj+Ijh4yaMGzNuzJhxY2pqa9NJRX/43e/feP11r8+XthzBRcTA2a2fOUzTTGaMeDyeTCZjsbi0WIlN6JxDVpJ8wYQToDQWi40bM2bi5ElSidu4YWNHe0djY+PHOz+WvzVi5Mja6hrJ85KZKZG9qcA2zwSREDJx0iQUnBDCAYltbhMBAGZFWgwZl9q2bdujv/ilfEzO+ewLZ48fO66rq6vw0gMo9q5MWtSyuVd/ig3IlvZDlhEALMn7SYr/sAOSQvFCxRLWsZCS1btOxt6dFtJLoFDUt2j2Gc3fh5nZkZjjkyeku7u74eOGPbv37Nm1e8+u3bsaGvbu2du4d1/apgGgqmLBWC6pyAGgs6Pz/nvve/apZ/yBgNQ0yqyzspRGiqJoGcPj8Wia5vf7UrmZ1puFIrHL0yR5kyN/2jDNMePHDxgwQDoc3nt3SWekMxgMvvbKK9IRyRi78orLuyIRmoEyOb/BLSzdLI1yz949AoASAnl3mOmdE4g55J758+n3B+a/9trmTZuZwggh4YqKO+650zk96CB0lJAeRMvgdyvKXEV7mxpcOOPcZMmgC6vQDRK5+RbYqI3lZw64Ic7oxUysMr/rfmbsvmg528ImHNdjfCEqqup8f2kPIyLq2c1/CCEfLl32i4cerqyq5CkTHoBy00gaSUop9kS9E/LzjLE//vq3W3dsD4XCt//37V6/j3MOFPbv20cpZe54AgvOSc7+kQbm3/761/qP1kmNNe3Ka21tlSEsy4kViExhma69/JSMzMmRueiCi0suvQQRVVVta21d8u4SIUQykdywfoNhGLInxOgJ40Lhip5cehsWZzsfpRyaoioEkoiqals5bZhmzYDaCcdNIBlF2WiB9YQAPPSznz/+m195vV4hxPCRIwcMGkSyS7mFVcTCYTj5KPPD3i4hryiuBHCMSLj/PBZzqV6p3inoRytYyFiatgvFh/t7a6TrqQuSHonsUFvBTYnZBfI5xEI5qUXCyrOJiLquf9zQEOmM+AN+ki7dAyApzggAUl3RU/pNGY10dubcVTKZbG9vp4zyDF/nwY5seVHvtR99tHrNGgA47fTTLrhwNiEkGAx+4Utf/MF3v49WKF+ag4Lkab7r69cvXrQ4GA6mE8Klmqnbk2Srqtrc0rJ3z566VOG5QKRptRqAIFZUVjLKZLi5M9LZ0dF+8iknT5w0SZYAqZr26c98mjFFCKFpmkzTEUIcf8IJY8aOqa+v9/t8AjH/KZTsN/JdEJXVVYbgmqbt2rO3rbVNdnNKs7H1cE0KoetaMBjMhLx8Q00I9Ho8H3+888XnXvz0Zz8tM0bzG/IUFdd1AkqH9o8FT2kJlXMOQU8HQKHu8v5KQMBeSeosuXipFwufSv56jvqWU+Fut+JolebpJr3BIbndTjrmqKgSKHfu2NHW1hYMBQkhPq/X5/OZhqGpKqE00tExdvz4hx75BRecUrp39547fvxjgiJT0WCMeTwe3aNz8yAAgcx/FgIAjOyot9fnDYVCAPD8s8+dedaZuscjhDhpxvTjTzxh7erVsjLEWU5gSa4tn88XCocCwUAmUMpScOukVERNVZubmnfu2Dl4yBAhBGUsHA61trUFdZ0gxpMJXfM89utfeb1ewUUkEvnJPffu3bt33PjxHq+HmxwJ+ny+WbMvOGhQc54uczzjzDPWrFmTiV+QbXo7m31bN29hQDVN271rV1NTU2VVJSFE9+h+v78rEvF4PISQeDwuOMpMJgp05YoVba2tTFXy+1KYQoRCwX/8/W9Tpk2edvzxsqg0l+XT0lCzt6GdEs4JQbCvYCuLW9s+jGB35OwMfDf7r9i/llN3XM7n3fthS8ZHLKQg29UXgrsbcFMZZfeYaKNxoA2g5KYNIFJKu7q6WltbZV1HdU3NDTfe2BmJtLS0NDU1eXy+L33lK/6AbPkXWLlseeuBFlVVM03VeDze1NTUeqCltbk5/b+WAwdaW1q5aZKMkup0a2XTND0ez8aNG5csWSJrvQkht3z605RSQbCgu9xl1SnmuUQlTmUOzK7OztVDKU0mkk3NTSRVr3nLrbcCIQeaDxxoaUnEEl/8ypdqamp8Pl8wFNy7a9em9evr6uouuvhiQghlABRyCChlebh8feY5Z1dXV6dFiHAtAOTkT502Td5Sd3d3y4EDiGiaZigUuvlTt0RjsZYDLU3NzYqifOFLX5JUaQTIrl27Ojo6VKbkX59KSjfEv/3lb5n9mfM9pAcREAgIEYtG5T0Vp1ECAbQ/q1DM4bQtzrXRI1w6DR0Shg6FRgaH+PMOIYheuawzi2hO2pZw4cqwTAgFd742B/cI2N+YnQKbeo0A8NzTz5xw4gmynu+WWz81fOSI/fv2CRRTpx5/3MQJpmkSxEgk8v6yD3Rd75ZnI5V2M2XqlB/feYfX4xEZ0Wpppb4y9+XmpiZKSGatd8/jc67p+rNPPXP+rFmqqgohps846cQTT1q5coXP5yvYxQyyk3aLDWGhC6eQvEmvzzt3ztwrrrhS3uS5551bVVW1aeNGQsjw4cNPOe1UIYTgAoAsWPg2EjJk8OChw4eiEEDpzm3b5732msfnS1vEyWRy+vTpJ82Ybprm4MGDTznt1FfmvlxVWWlRZu5QnApACKlfvx4ooBCqqj737HNnnHWmDKlffe01gwcPbtjVgIjHHTdx6rSpMq8gFou9t+Q9TdNQoKXbRwgR8Ps/Wrt2/rx5F110ERciM5kfM3yUB9EJQCmFFCODWhHLOKvuM+xKCwiWX4Z4RAbaW5olmOToWP7UKxEbB20IXThkiWMmQG81zEGBXq932dJlzz/z3LU3XMc5R4FnnnVm+gOGYSiKAgD/+Ovf16xaPWBAbVdXd2ZnghEjR44YOdLy4ss+WLpv715KKWNKvm7r1fWtW7e+9fobsy++SB7mmz99y/IPl6UfO51wnlkubak+YzYXGdhjHyXEtCcWyvwh+buapjXs/Pg3v/r1t27/LwCQTDxTp03tsVgNEwAUVXn1pZfnv/YaZeziyy5FRJNzRsiCBQv/+Ic/VVRWyORQSmkk0rXzogunnzxD/taJJ5y08I03RYraPfPXKWbtcMxgoJD/HTZ0CBGIiF6vd+2aNf/35P9++rO3Sm39lNNOPeW0U3OW79///NfS99+vqq4WVq4GmppGr9f768efOPHEkwYMHCA1VjvhhEgIgCZ7JhaVR8kNQwawRKHTjmXs7GI/6caEdxP26V11Elx4EhyUf3BNEUSLMdKLzakspw8PluGvKCEVzMn2R9Q9+p/++Md//e8/GWOKqkgOCKnWqapqGubvf/u7N994IxQOc4EEUYZuM8m684dpmlxwCsBFD6dhZsOZHqWD0pfnvmyapjTnJ0+dcu7Mmd1dXTRF3A3ZlrulVYhIPF5v+sqyLTCkmruS7ICv3bQLRFnwLj8sH1Bih9/ve/nlub98+BEhRDoa09MwUlWYwp7+91NPPvmk1+Opqa4+buJxso0EpfStN98cNnxYRThcXVVVVVVVWVk5eHBdw86P9+zeLX9r5gUzQ5U9sW9I/WjPPahKTqidIOqaRgiRLL8m7+nkgEL4vN5//P3Jv/7pL5RSOZPZy2f89te/ee7ZZ4OhkOCS+Y6w7JlJiwpFURLx+B9//wdEzPmMJTiU0lxM8XgIBWc/tDMWCHsUyNGkRK828EMbbR/LO/lusCzfsBVFxoXsEs5JIZlECimbaFMo5RxOwcMSOCoNgm0/D6Bp2p/++MftO7ZPnjz5kssularE/r37FixYsHb1muUffhgIBIBSzrmqa+s+WnfOeeeSDBJcC72B80QsgQBAQTZFkP64dKk1CuH1+erX1b/1xpsXXDjbMAxN0yZNnrz4nXdIRr60mUy2tbVJTsa9e/Z0dHQoGaXZiKiqbPWq1ZMmT0bEZCKxfds2VdMkOXC0O2qmemqjVXA5M6j18c6dba1t/oDfNM0N9etTlMA9HXdfmjOnqalx6tRpl15xmYwjRyKRN+a/vnHDxrcXLvR6vUnTnDJ2zMhRoxKJBGNsxYfLOzo6GKVpbJI+yt17dm/cuGnQoEEcEYUYOWLk6lWrJbhvqF9fXV0thOjs7Ny7e09PI/jULaqatn379ng8Lhkqd2zfkSkzPB79yb//vWFXw+Qpky+9/DJZV3OgufmtN95ctWrVsqXLQsGQtM0pACJ2Z89MehUF5z6//+0FCwcNGvS5L35e8oGW5vq3qJeUOuofnvjNU08/Ha7o0bQPp01aVKlir5y6XjR4nS/iPqaP5YXFD91sOIsrsELhI9IEiTLW0dHBGBswcIAkeUwmkweamxVN9fv8mHHgORfhyooCqW+IXV1d0qDVdN3j8SBBINDV1SU4z+n0HQyFZGZdMp5Ipkru0rqeruvpMG48HlcozQ/UhCsqCBAU2NnRCRRkc0FN0zxer4S8aDRqGAZNlfFZlL2bZiAYlNprV1cX5zzzw5Sx7q4u0+QDBg2UjjnOeXNzMyEkEAgQycOmqt6UbhvpjHDB86tiBKLP51NVVV42Go2ahkEBBCJlTCblcM67IpF83ZkLDIVD8q7kFzNVQsqY5GEaMHCg/IxhGM3NzYqi+P3+TFASiLqcGYJAsmamZ+2AcJNXVFZK6uKuSBeiBZVGIpn87+/+zwUXzpaZqq6DOYoCmSTvLqw5LOaw2VE2QKnH283nS/siuPBJu0zoKeiZze85YancuSF5LHhj4KjvF4u5aEXzgY7RCTw0QJ/WJsLhMCK2tbalwzUVFRUCMWXnpTUj2t7aWvBmFEWRtnMiHpfhUZTNCLNREgmRV5MdFGg2HwMFiMfj0WhUthVkGSiZydTd1tqa/tG0mpxMJmOxGKa0OZpnRWK21dkViUjvpJL3YcG53+8nAJHOzrSLVlK08ZRjwTSM9ng8/ZiMsfxwMAXo7u5OOwrlXaUbMMinAACFsfwWUoxCe1sbyXuctLoWDoUQsaOtLU1fHwqHSd7yUauZySI5RMIUJWdKrfdkCc3FcnrmuMEvhzBcbylEWCQ8kTIyIsGFcxMdA/fleF2JFUyX/BQFxRWWulJp50yxPsryAzgOnXN6Kt44l46t9J7kGSwVmSOtE6GjVpkG3HRYoCdOku13Zqqa1cwleyYZpUr219O3LVJyJd1dNh3wgVTXWcy+GVunPGIaETIvkqm3plEDMt6BDNRI/xzY97BVKCWyG0R2CSAFoBlPYdsBOHeeDj5LT1/cjEa7aLN8+TMDeYazlvqA9c0AIYhJ++Zi9lHvVM8csHe0YZEtqBx0Ger6i8WCYAkGcv6tCvucZ2L1FFBGyKjXm9CK4psAg2uWNucbtqx/EL1NwOysVqe9SwVBEF27tnMOdq4oRRQ2vSchr6bYkmXH9vqIxJHMAm1u0qG9pANFHmb81WnCU7Nn+b7TTNqgbxapc4rkA108rJPIz4kmZZeNETwYZ7OMetvXeisKpQCUEkSWXU5EMuqKMr0zcmpkMFB2rQOS8fmsbBKUvEY9F5YtlnpeQv5vEXvOiJ7FzvuWfIv01K0dbOTU49UmPfWxPXfQQ8+HBz+cuoJ8HiZfZDyLPbLgwRz/jPtHq5vM+N2eSUs/a+7zWs3/wRlONdzMnOqDTvd0d6fUw2Y+NaSmPetOsvVEy69nT2PPX3rEdcZ9Zl4f0/djiS82b4IVTZ/IErcoNzqmJj/zgIBNyUVOhha16smRdh2gDRMzOkbhMHNX25NGWzZYtiMVJVb88GkgyPFaYvYDZkJYzw7PVggs58eOLDHfiESrp8i5DqYWS+TcUtZa96waWjU3zZ/k1JboQRXMOTI2Wo7cqxKFAKisVC3a9I5HItHuqK7rnPM0kpBsTMHMdyQqU5DM6PKF/CMAoBAkx3EAgAJJz18RCaHQI2xzzqSwIl7CbBtBCEx/nfZQ9ve8QCQIRDqY5U4SaYi3Qp+MR0QZWevhwhOCQg/9Sub95J+3HphAAj23JO01SMtnchC1CSEH50p+xkKDQ8lUBT09AgkI7KGAPvitnp8DgiKn4bS8//SDZD21vHJantGsGcg0bfLnKnMae7BICAKUECSI0DNXmDNp6ePhXtV1pQsDoEAKPS9ycpqJQLtL9JYXyNqhgQg9E5L7abtO6KXdYc9BI4Cp1XfKWzi46ILYhIPKt8wc1FjIX6M8+CP2n3G4q4NXTj2jQEEy+u5m6uaQghcChBJIGMnifJQy4nP+xRfWDR8mg/qIROZ5JpMJVdUyXxhG8qCGhUTTNcMwUKCua4ZhCIGUUUVRZCvLzCdSNTWZSAKApqmy666iKkBIMplUNY0QYiSTmqYTgoZhSsQhNiXAmq4n4gmZcmUYSU3TM1+YpkmA6Jom44+apiVSL4xkEknen9IPayQ9Hk8ykUBCdF2Px+O6pnEhuMnl/UBeRJsQAgQ0TU0mk6lJI4ZhEkI0XUsmkwrrmUaZ8SD/pOtaMmkgoqZrRtLowdIsZYEwRpmiJOJxRVVlD3uPx5NMJBEx/XXZLjWZTOY4swkhqqYZyWT6RfqpEYnS8y1D3qRcPgJZGk3Ph20mLZlMEgKarqWnyDQM2Z++5wXnXLa+KqQnFqywtAyvSxdVIpGktOdFhqYEmqomEsn8I2fXtMdZz7XTdomNraNqmsjYM6RQei/Y6IPEJgaQPnqUUcZY5urna6np7zCFMUqTyaRjR2prD4ydOow2q5Ond6fPvsUMZx6iRN5nSAHLI+PKSORxMPKeMe390FRN4oMU9pTRM886Kw2AJM/LebQUs/SP/tE/+seRGfZRb0QhhFQCMNvRlvsiJwSEPa5R6Y0AAgSsIk0Z5FcEi/kJS7PL8lspEzr/5wq/SF8h9U7uBR3vJ+c6PZ7KlP1peW+Y/oydBIW8p8v5lsN0FXrYjDflqhXz9bwpyrtPq2v2bsiqZ4+lN2z+n47AyHT+HvIfKupJXZ6sQ7VcUMQhKvnKjs+YBTipL1Bm66Ps1yj7R//oH/2jwKD9U9A/+kf/6B/9QNk/+kf/6B/9QNk/+kf/6B/9QNk/+kf/6B/9QNk/+kf/6B99d/x/2chPaLC5QfkAAAAASUVORK5CYII=";
  // Coolstream (UK) Ltd logo — extracted from their letterhead; shown on F-Gas certificates only.
  const COOLSTREAM_LOGO = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCABpAZADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD5foopCa/VixaKarZ6c0vPpRYBaKTn0NHPpRYBaKTn0NHPpRYBaKTn0o59KLALRSYPvSbu3eiw7DqKQUtAgooopAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAU1h1p1NbvTQHrvgjwLomreF7G8u7ITXMqkvIXYZ+Yj19q3P+Fa+G/8AoGr/AN9t/jTvhv8A8iTpn+43/oRrpKG7Hx1avVjUklJ7nM/8K18N/wDQNX/vtv8AGmt8OPDKnB09B6Zkb/GvoP4Q/s86p8R7Uazqdx/YHhZRuN9LgPMo5JjB4C/7Z49M16DD8S/hb8K7oaX4B8KyeMdaU4+2bDLubpkSEFiP9xcV5tXHRjJwpLna3tol6s1gq7XNUqcq/E+SJPg9pUNmbuXw9cxWqkAzyRyrHk9BuPFJefB/StPhWa58PXNtCy7xLNHKqFcZzuPGPevpz41eO/ib4u+H8w8SeEYfDvhhpYWL7SJM7soOWz1x/CK6TQfi38WPCfhXSxqXw+j1vQI7WJYZoIyWMIUbWIUvn5cfwisvrlXkU1GLbe3Mae9zNe0lb0Z8Zr8N/DTYI01SP+ujf407/hWvhv8A6Bq/99t/jX2DBN8Hvjy7Wj2jeBfFknyKwVYd7+n9xz7MA1eO/FL4Pa/8J9UWDVIRPYTMVttSgBMU3faf7rY/hP4E1vRxsKsvZzTjLs+voY1PrEFzRndeXQ8g/wCFaeG/+gav/fxv8a4n4oeFdL8O6fYSafaiB5ZijEMTkbSccn1r1yvOfjX/AMgvSv8Ar4b/ANBNegaYOrUnXipSdjycUtMZtiFjk4wMKpYkk4AAHJJOAAOSa+0/gL/wTf1DxlpNrrvxK1O70C0uEWSLQNN2rdFCP+W8pzsPP3U5GOW7Dmr4mjhY81aVvzPqvM+Ls0Zr9ZbL/gn78DrG2EbeE5rk9PMuNTuXc++S9ch4+/4Jo/DTX9PkPha51XwjqeMxyJdNdwE+jRyluPXaQfSvKjnWGbs0wuj8yqK7T4wfB7xP8C/GsnhnxXbxpdFPOtLy3z9nvoQceZET6HhlPKkjPBBPF17cZRqRUou6YBRRSbhVgLRSZpaLMAopM0HnFCAM+tAOa7r4C+A9N+KHxo8IeEdZNwulaxdvBcNaymOXaIZH+Vx905Uc/wD66/QL/h2P8IgwzdeJyM/9BYj/ANlrzsTmFDCyUat7vXQND8xKK2/Hmi2/hnx94o0W0Lm00vVbqxgaRtzmOKZkUse5woz75rDzXfF8yTXUQtFJmjNUAm40bjXe+HPhWfEGiWuof2n5HnqW8vyc45x1zWV428DjwctoRefa/tBYcx7duPxNM5Y4mlKp7NPU5mimjrS5pHULRSZozQMWik3UbhQIWik3CjNAbi0UmaN1AC0UmaNwoGLRSbqM0B5i0UmRS5oAKKKKQBTW706mt3poD3r4b/8AIk6Z/ut/6Ea+gf2efhBF8Rtfn1PWR5fhfScSXTMdqzuBuEef7uOW9sDvXz78Om2+B9NPUhG4HX7xr7D+KCT/AAs+A/hL4f6YFTWvEbKLsoeXLkGT/vp2RPpXm46rKMY0oO0pP7l1Z8lGEXXnUltH8xNS1TXP2oPFUugeH5pND+HOlkJNcRpsWZR9046EkDKp0AwzdhV1vif4a+F96fCPwk8ML4l1/wD1U18AZAzjhiXHzSEHqchB0zTvig8/wv8ABXhf4ReEMnXtaAF5PEcOQxw7E9QXbPPZENN8T+KNG/ZT8NW3hnwzBb6h4xvIVku76ZMiMH+Nh1xkHanTAyff59JVFGMVdP4Y9/70jvlLlu27Nbvt5I5T406f8Xbj4f3Or+Or+0g0Tzos6Vb7A24thchR2Pq9dP4fk+PHgfw1pepae1n4o0L7LFLHZ7VeVISoIXGEbgEDILH2r548TePPEfjO4ebXNavNS3HcYpZSIh6YQYUY+la/gn4yeMPANzG+la1cNbqRmxu3M1uyj+HafujH93FetLB1PYqFoXXS2n37nBHEQVRyvKz6nuUV54B/aa87TtV07/hEPH8YIV9oVnYdR0HmD1RgGHb1pfA/ia80/Vrr4O/FWH7bb3KeRp+oTNkSA/6sBz16ZRuoIwecZj8S6bpX7R3gWTxr4Zt/7I8faKA9xDC2HcryBkdcgEo3Xt6ioPEl0v7Q37P6+JQuzxd4XJaeSNSrsFAZsdxuTDj0YV5aSsoSuo3trvCXRp9ju1+Jav8ANf5nh/xS+Hd58L/GV5od2WmiX97a3LDHnQn7rfUcg+4rwz41f8gvSv8Ar4b/ANBNfbvxSmX4xfs46D43YK2taK4hvJFXkjPly/hnY/pXxF8awf7K0vsftDf+gGvo8HWlWpWn8UW0zno01TxcOXZ6o7z/AIJ+/Ce1+JXx1fVtTgE+l+E7VdQEUgOyS7kYpB7HZtkbB77D2r9WJpkt7d5pHCIi7mZugHqa+Df+CVixfY/iY/Bn+02Q99nlvj9c19pfFBp1+Gfitrbi4Gk3Rj/3vJbFfH5tN1cY03orI+lPgH4kf8FM/GNx4wvIvBOiaPaeHLW5eO3m1RHmnvo1O3zCFZRGrEEgDcdpBODkD60/ZN/aUT9pH4f3Wq3Wnw6Nrul3ZsdSsYJTJEr7Q6OjMASrIynBHByMnGT+Nnh9g2g6aQODbREc5ONgNaQuLi3AMFzc24br9nmdAfrtIz+NfSYjJ6E4ezguVrr/AJ6jP1O/4KJeAbPxd+zvquuBY21PwvImqwTcFliBCzqP96Mt+IB7V+fPwJ/Z78YftDa/caf4ahhtNPsyBf61eAm2tCRkJgcvIQQdgxgHJIBGfM7zWLq3sbmWS8vp1SJmaKS5lZWABOCC2DX7Sfsx/DWx+FPwP8J6FZp+8+wx3V3MygPPcygPLI2O5Zj9MADgVxVJSynDKEZczk3by/MD5y0D/glr4Rt7dTrXjjxDqV0wBf7KkFvEG77RsJx9ST71h+OP+CW9otpNN4M8d366goylnrlvHJbuPTfGqupPTPI5+6a6j9ur9rDxj8E/Fug+FfBUljY3NzZNqN7fXlv57hS5SNEUkAZKuSxzwuAOcj1n9jP486r8ffhGdY8QQ2sXiHT76XT71rFSkMjKAySKpJK7kZSVycHPJrz5YjMadGOLc/dYuY/KDxx4I134beLL/wANeJtOk0rW7EgS27ncrKfuyxt0eNsHDD0IOCCB6X+zz+yj4y/aKmlu9MeDQvDFvIYptevoy6PIDhooYwQZGHdshVPHJyB9gf8ABSj4Sp4u+H/hfxLYosWv2WsWujx3CKu5ob2ZIAhJHIErRN/wH619WfD/AME6Z8OfA+i+GNHt1tdN0u0jtoYxzwoxknuScknuTXbWzi2GjKmkpyvfysVc+SNI/wCCW/ge3t9t9408T6hNjmQfZ4hn6LHXEfEj/gmBeafps934C8ZTaleKGYaX4giRVlwOFSaJRsOe7K34Vf8A2wP21PHvw3+M114O8DXGm6fZaRbwtd3F1afaXnuHG/YQWG1FTZ05O7qMc/V37NvxZl+OHwX8NeMLm1is9QvYnjvIYSTGlxG7RyhM87dynHtXJLEZjh6cMTOekhXZ+ZP7LOiaj4Z/a98AaRq9hcaXqtlq00N1ZXS7ZIXFtN8p7HjnIyCDkEgg1+xLdvrXyZ+0H8ObPT/2vv2f/HdrEsN7f6nc6PfMiDE22ynlhZj6qBKB/ve1fWR6CuXM8QsU6VXq46+t2gZ+JXj/AMP3nib44ePbSyRS/wDwkGos7ucKi/aX5Jrbs/grZKg+1ajcSv38lVUZ9sg10dlLD/wt74qR7lFx/wAJHetjvs+0S/pmtPxBps2saRcWlvePYyygBZ4+q8g/rjFfd0v4cfRHgYzF1Y1vZxfKu5xlx8FbBkIg1G6ikxx5iqy/jwK47/hXt3beKrXRruTy0uQxjuohuVgATwD345HvXcadpvjDwrayQwPa65HncGnlYOvHIGe3frXJ+J/H2uNdW8V1Yx6Vf2rmSNtp3DIKn73BBB/QVoaUamIlJxjNSXc9X8O6OPD+i2uniXz/ACFK+Zjbu5J6fjWT418FjxiLQG8Np9nLHhN27OPyq54L1K41bwvp93dyGW4lQs7kAE/MR2rnvil4k1Lw6umtp1z9mMrPv+VW3YAx1BoseXSjWlieVP3rnIeG/h2viC81aA6gYPsM5h3CPO/rz146Ve1b4RT2ccAs71ryaWZYgrR7VUHJLE+gxWv8HLiS7j1ueZt8sk6u7Y5ZiCSfzr0SaZLeF5ZXWONAWZ2OAAO5oOyvi69Ks4J7Hk2vfC220Hw3d37X81xcwxhtoUBCcgfXvWF4T8AX/ixTMjC0slODcSDOSOoUd/5V3HiTxxovibTJ9Is7iV7i7ZYY2ETBclxzk9upz7V3VlZRabaw2sC7IYUCIoHYCgHi69Kl7/xM4OP4L6aqgSX147eqhVA/DFZeufBqW3tzLpd4biQDPkXAClvYMOM/WtXxXaeNr/W5W0t2trBCBCI5VBcY5Y/U11/ht9SbRbb+10VNQUFZSpBDYPDceo5pkSxGIowVT2id+h86SwyQSSRSI0ckbbWVgQVPoRXoHh/4Q3WoW6XGpXJsUcblhjXdJg9M54H0q38UrGPR/EOla4sKyqz/AL6M8B2TBGfw7+1aOm/ErW9YUPZ+FpbiM/xrMQv5lQKDuqYmrVpRnR07jv8AhTGkgAG9vd397K/4Vlax8GHjiZtMvzNIoz5VwoBb2DCrf2Hx9qWrfaftC6dCZARCZFKovpgD5q9I6Dnr39KDgnia9Fp+0ueD+D/BTeKNQvrSad7GS0UFgU3Hdkgg/St7WPg/NY6fJNZ3zXtwCqpB5QXcSwHXPHXNdRoMax/EvxNt4DQQMeO57/pXVahfR6Xp1xeTZ8qCMyNt64AzSuXWx1eNRcr6I880/wCC8P2cNfajJ55GStug2D6E8msPxT8LL3RVSXTmk1KF2CbAoEiE9M44Iz37d663wZ8Sn8UawbC4sktmdGkjaNy3TGVP4dx6V3ZbaCc4HegiWKxVCp7+7PL9J+Cwkt0fUr9o525MVuowvtuPU/hUGv8Awdezs5J9MupLl4wWMEygMw/2SO/1rU0v4s/2l4kisDZLHZTTeVHLvJfrgEjp1x+deiLwaYVcViqU05vc+YOc4IwR1FLWn4miEPibV0UAKt1Jgf8AAqzKk+li+aKYU1u9Oprd6EWfSPwIsV1K38HWkn+rnvoY2HsZwD+lfY3xGU69+1/4H06TDW9jbLKqNyBxK54+qr+Qr4x+DOpf2No/hjUO1rcRzn0ws2T+gNfZXxkuI/Cv7S3w78USPt0++jSEydhyyfylX9a8TH39tHzjK3rY+aja8/8AEvzJvCkI8VftleJLu7/eLo1oUt1b+HCIoP8A4+/5181fErxBN4o+IXiTU53LtNfzKuf4UViigfRVFfSUlwPhv+2M010fLsPE1qFSV+F3soAAP+/GB/wMV4J8cvBdz4F+KOu2c0ZS3up3vbV+zxSMW4PsSQfTFYYBr20b9YK36/iZYlS9m7dJO/6HB0UUV9CzyttTf8H+PNf8AXlxdeH9Sk02e4QRysiqwdQcgEMCOtT+HfiR4j8JjVRpOpvZrqpJvFWNCspOcnBGB949MfpXQ/CH4K3nxXTVrr+0E0fSdNTM19LEXUtjJUDI6LyT2yPWnfDv4Mnx/wCHPE2v/wBtR6ZouilsXUkBf7QFUuSBkbfl2/8AfWK4KlXCqUue19L6fd6nVCFZpcvnb9TltK8fa/onha+8N2WotDod9u+0WfloyybgAeSMjgDoe1eM/Gr/AJBelf8AXw3/AKAa+ivD/wAH5da+EOq+Pp9UWwtLJ3jS0aDc05UhcBtwxljt6dq+dfjV/wAgrSv+vhv/AEE10UpU5OXs909fU6sIpqvT5+u3oem/8E5/ida+Bfjde+Hr+ZYLXxZZrbW7ucKLuEs6J9XRpMf7nvX6j3Mcd1aSQSKJI5EKOvqpGCPyr8E0Z45IpY5HhmikSaKWJirxyIwZXVhyGVgCCOhAr70+An/BSa0sdNtdG+K1pdC6iAjTxFptuZkmAwB58KfMr88soKnBPy8Cvn81y+pUn9Yoq/dH1R5p8Tf+Cc/xN0DxhfxeCLXTdf8AC80zSWElxfC2nt0Y5WGVSpyFzjeCcgDIzkn66/Yx/Ziu/wBn/wAB6lF4me0v/Emt3K3d6sH7yC2CoESGNmALAAElsDJJOBXSWv7anwLvIRIPin4agPeO4vlicexVsEH2PNcr48/4KEfBrwppskuleIP+E0vdp8uz8Pp54dgOFMpxGmfVmrzq1fMMTTWHlB29GIq/8FCPFGmeCv2X/FtilvbDU/EcX9i2ESood3lGHYf7qB2J9FNe0fBPxZZ+NvhL4R1ywnW4tr3S7d1ZePm8sBhg8gggjB9K/I/4+fH7xJ+0R4zXW9dIs7C1VotN0iByYbSMnJYn+ORsDLH0wMc59G/ZO/bHvv2eRL4f1yzuNc8E3ExnENrg3GnyMfneMEgMh5YpnOckZJxXZUymp9UUVrNNt/Pp8rfmM9M/4KWfC7xNqXxE8O+L9L0HUtb0d9L+wXE2m2j3Rt5UlLKGSMFsMJGwcY+U8jNe4/8ABPP4Z678O/ghdy+IdNuNHvta1OS+SzvE2TJDsWNC69VLBN2DzgjIB4rrND/bi+ButWUVwfiPo+lM6hvs2rSGznXPqkgBFZHjj9v/AODHhHTZJ9O8Tx+L7vkR2nh5TclmxwDJ9xPqzAc1wyni6mGjhPZPR72YjC/4KI/Eaz8B/Bzw+Jz5lxceJ9Mu4ou5S0uUupT9AsJH1Ir6f0vVLfWtLtb61lWW2uoVnidTkMrKGBH4Gvxi+PXx68RftCeN217XESwtLdWg03SYXLx2kJIJBbje7YUs2McADpk+2/sn/t0H4L6DaeDPG9pd6n4Tsxs0/UbGPzLjT4+SImiHMkQ6Lt+ZRgYIGa6q2U1I4WCirzV7r1/yGZf7ePwd8Xaf+0RqmvWPhjWNX0XxDDbTW95ptlJdL56p5ckTCNWKEbEPzDBDcHg4+4P2Mfhxqvwr/Zz8KaHrlq9hq7LPfXVrLjfA88zy+W2DjcocA+4osf22vgXfW6yH4o+H7IkZMN/dC3lX2ZHwwP1FcZ8Sv+CiHwm8I6VKfDuqP461QjENvoqloS3GN85ARR9CTjoDXPWqYvFUYYb2TVutn6AmXv2jvFVr/wANHfs5eGEkDXr6/eaq8Y52xJYTwgn6tMB+foa+l27fWvx48FftCXevftWeHPit8Qb3yra3vGkmW1jeSOzthDKkcMSAFmClxk9SWY8ZwPu//h4t8EDx/b2pDHro9z/8RSxmX1qSpwjFystbLrdsGj89PGHhvXtQ+MHj/UtEkSF4PEmpJ5nm7SD9pc4I9MGtK98WeJvCtiLnWtMtbqHeEMtvLtbJ6EjBFYN38S4bP4oeMNYtFku9E1jWLq8jBXY5jeZ3RwD0O1hlT612kHj/AMNapblZNQgEbjDRXK7fwIIr7inpBJ9jxMZz+096HNHy3LPhHxdb+LrKWe3hkgMT7HWTB5xngjrWV8WLCG68KyXDoPPtnVo5O4yQCPoRV0+OfC+l222LULVIxyI7cZ/RRXnXj74g/wDCURpZWcbw2CNvZpOGkYdOOwB5+taHFh6M5YhSpxcYruejfDn/AJErSv8Armf/AEI1j/Fbw7qGu2+nvYWzXRhd96oQGGQMHBPIrF+HvxFstI0tNM1LdCImPlTKpYYJzg454Jrsf+FkeGwOdTT/AL4bI/SgUqdahiHNR6nO/BqCW1j1uCdDHNHMiOjdVYA5Bro/iSxTwTqe04JRR/48K4/wn440jRdU8QTXU7rHeXZlhKxsdy5PPTirXjb4haJrXha+s7S4ke4lUBFMTAEhgepHtUmlSlUlilPl00PNtHvRYaxZXLYCxTo7H2DAk/lmvpQMG+ZTlTyD7V8v7eua9E8E/FJdLtY9P1ZXkt4xtiuk+ZlH91h39jQd+YYadaKnT6Gp4u+IWt+G9cuLT7BA9vkNDIyt86kcHPrnIqez8R+N761iuINCtTFIu5S7bSR2OCa6GPx14cuEDHVLXHXDnBH4Gs/VfiloWnxEwXB1CY8rHbrwT7seBVHlrmaUY0de5jM2reI/FGj6X4j0+2t4lL3Sxxvu37VIweTxkivSFURqFUAKvQLXgR8cXsniuPXpVVpEO0QA/KI8Y2D8CefWvWbH4jeH76ESHUI7VscxXB2MP8+1SVjMPVioWjp2Xc5O++KmpX2rDT9J09I5Wl8oGYF3PzYJ28AdCevGK9P/AIfWuM1r4naDpcLyWbpqF2QdogGBn/afsP1qSP4r+HfLQvcSo5ALL5DfKccjpTMq1Gc4rkpWQaL/AMlL8R/9e0H9a1vGX/Io6v8A9erfyrjbDxvolp4x1TUjdu1td28aL+5bIZc5GPpzn3q54k+JGg6loGoWdvcyPPNC0aAwsASRx24pGkqFX2sHyvSxx3wrYr41tAD/AMspP5V7dL/qZP8AdP8AKvA/AutWug+JIL29cxwIjqxVSx5HHAr0+T4q+HGjdRdyZKkD9w3p9KZvjqVSddOK00PJfDP/ACNOknv9sj/9CFfRf8VfN2i3UVjrthczNthhuUkdgM4UNkmvYv8Aha/hv/n6l/78N/hTKzGlOcouKPJvFn/I06x/19SfzrJq9r19FqGvajdQEtBPOzoxGCQTnOKo1J7tNNQVwprd6dTW70I0PevhyN3gjTB/sN/6Ea+w4bV/j7+zbbRWjGXxZ4VYKsYbMkmxcDH+/Hgj/aX2r48+G/8AyJOmf7jf+hGvWPhN8Tr/AOE/i2LWLRGubV18q9sw2BPFnOB2DDqD659TXBjKMqsFKn8UXdf5HyHtFTrzU9noe5+XH+1B8IbKW2uEg+IHhvA2s2x3YADOewfAIPZx7VFpfi/wz8dtDj8HfEkt4b8a6afJhvpgImMg4yCwwGOBuQ8HqKteI/Atxqt9D8WPg3fJJcSgyXmmR/8ALQnlxsPc/wAUZxyMjnrQufiB8MfjkPsnj6wfwd4shAie8OYsMO28jp/syDjNfOpaXgnZO+nxQfVW6o9B7+9a/wCEl3uecfFT9nXxB8LtJn1qe9sdS0OORY1uYGZZDuOFzGQf0JrovA/7KOq6xp1rrPiXWrHQtBliS53xyB5miYBhksAqHB7k/jUXxY+EVx4D+H9xf6b4/bxF4bEsQGmNJuHJ+UgByuB16Ct/TPgTp+peG9M1Tx/8TmTSDbRSx2H2gKsaFQQnzsRkDAyFzXdLFzdFP2ut91HV+Vjl9jH2r/d/joSeLvGdt4psbX4R/CG036dICl5qEWRG0ecud/Uqc5Zz16DOatfFeSDwV4M0P4LeDm+363qDot/InUljk78dC7ckdkB9qavxd0TwvC3gz4JeHX1DVbn5X1Pyi59N+W+Z8erYUVoaTo2l/sz6Hc+LPF10uvfEPVVYwQeZuZWbqATzjpvk9sDsK4orkauut1HduXRy7JHT8V236vol2RhftHalZ/Dz4deGPhbpk/myQIlzfuvUhclSfdpCWx6LXxT8a/8AkFaV/wBfDf8AoJr1jxJ4i1Dxbr17rGqz/ab+8kMkj4wB6KB2AAAA9BXk/wAa/wDkF6V/18N/6Ca+lwlD6vSUW7t6v1Zz4ep7XFxklZdDifAvw88RfErU7nTvDOnf2neWtu13PGZ44VjhDBS7NIyqACw7961fFnwO8eeB9Fk1jWfDrRaPC6pNf215BcxQMxwgfy5GK5PAJGPeup/Z1XR30v4yL4gF8dCPgK++3f2Xs+1eT5ke8Rb/AJd+Om7iti30jwd4D/Zr8a638K7PWtXh8SyQeH/FEuuSQR3GiwBi0TCCBAriViAJt3y7v9kgRKtONVxW14rbvvrfTTZdT6hHgzbV+9gE8fNXQ+BvAOv/ABK1qXSvDlit7dwwNczmaeOCKGFSAXkkchVXJA5PJNe8eEvD3gfwP8NvhRdajfeCLe+8X2f9o6pH4t0a4v7vUVacL9ktJI8CHyx8gCgtuZWIz97O8E3unfD6+/aW0zQNJsNW0Kw0C5nsV8Rac0k7xCWPbBMsm1vLG4gowBO0MTk1MsU5KahHVd9t7AfPt1bvY3lxazbVmgleGQKwYblYqcEcEZBwRwe1XLzw/qFjoemaxPb+XpupPNHaTeYp8xom2yfKDldpOOQM9s16jpmoaT4L/Zf8N+IovCXh/V/EmueJ9T0WTUNWsvPMFqsbyDywCAHXYqq38POKzrrwbpF58I/ghKIodOvfEPiDUNN1LVVUCWSFb2OJCzdCURiFJ6fpXR7az1Wl2vuvf8gPLdyn09aNwUDHGfwr6YWTw/q3xG+MvgBvhz4btNK8H+HtWn0u6trArqFhJbhFjlnnLEyNLvMgLY5GRnrWN8OdH8JeE/2ffDnjPUNV8FaRr3iDVb+1kvvHGkTalbrDbyGMW8KoQsbOB5hYncQeOBkZPFcseZx7ba7ptC0PAdw6/wA6M4y2cDrn+tfROieFfBGj/tEfESHT9Ah1rwrpnhG+12y0jVrWZI4rhIoJAmyUCQIHZ9uR9xgBwK434Vt/wm3ijxb4r1HQPBFtZ6bp0d1d3GsIbXQdFkdhHFcfZV3GUs6ELFkAksd2QBT+srlcrOySf37DPKYYWuZo44k82aWRYo0Tku7EBVHqSSAB71s2PgjXdQ8QX2gxaY66zp8c0l3ZzSJG0AhGZdxJxlfQHJ7Zr2vx9aaHpep/ATxposPhnVLvWNaa3vbrRdGey0vUDHfQxRzLbSHO5A7bZAcMyq4zgVJLaab8Qv2wfihZ6xo+lXVla2mvMlrDbBI/PtxmKZlyczZJYv3ODgULESlFySto356OwHzmkisokB+UjIPTg0/7o5Fel+G9Usfhl+zf4f8AH0WiaBrniLXten0qW+8TWQvLawt4bcvsSIsqh5SCxYnO3p049F8P/DzwqP2qvBWlP4atrfw7rvhiLxBd+G5gWhtppbG5kaFVPKoHiVlHVT6DFVLEqHMraK/4bgfNqsOQpzj0NLmvUrzWLH4nfs33HjObwr4e8M61pfiW106CTw7ZfZVeymtRKIZhuPmMjNw/U+2TXlNzcC2tpZmBYRoW2qQCcD3ropzc78ys1o0B3Ol/BXxzrPgtvFdn4fkuNCEL3KSCeITzQJ9+aKDd5jxrzlgvbjNcSrBl3A5U8gg5zX2p4e03T4r23+BGiahCnxx8P+HPsOm+JdTswtudPuSkt1Z2wUjiOFwElcHOGHJDV8c63osPhnXtU0S3uUvYtLu5rAXMcTRJKYnMZZUY5UZU4Bzxjk1x4XEOu5KWnbzXcW5UiheeaGGNTJJNIkMcajJd2YKqgdySQAPU1seMvBOu/DvxFLoPibTJNI1iKKOZ7OZ1ZhG+djZUkEHB5B6gjqDXoP7Lvh+w1L4qDxLrd1a6f4a8F2b69fXt8+LeOVfktVlIBIVpDu4Gf3Rrpvjdo8fjD4I+HPGa+M9D8eeIfC96+i69qGhtJs+z3UrSWhZXG7KuxjGc8SZz2rSVflxEaVtHa/z2/rzQzw7VPD+oaLa6Vc31v5EOqWovbNt6t5sBJAfAJ28g8Ng+1Z64bOCDj0r3jwf4J8P3nxF/ZisrnRbOey8S6HFc61bvENuoSGKcl5R/Ex2Lz/sj0ryrx94sTxd4glnh0HRfDltatJaW9nolp9nj8pZG2GTk75duAz8Zx0q4VXJqNul/xa/QbuYum6beaxqNppum2c1/qF5KsFtaWsZeSaQ9FUDqe/oACTgAmu28Vfs//EHwX4fuNb1bw8q6ZaAG9ks763unsQTjM6RuzRjPGSMDuR1roP2YfPPjDxmuk+Z/wlbeC9WGgmHG8XexP9Xnjzdudv8AwLtmvPfgzp+u3uta1D8O5Ps99/Y9y2sNCyxL9gAHni4ZxgemHw2Q2OQaU6klKSTSStv5+fQWhhN8vXj8aDwP0r1DTNS074Xfs86D47tNB8Paxruu69e6dJdeKLD7ZBp9tbxErCke5QHlx5m487c47V6RoPw58IQftVaJpD+GYF8Oaj4Q/wCEhn8Ny5MNrNJaSOYVycqgZNyj+HcMdBSliFHmbWiv+Frr/g9QXkfM6kt0OeccGtPwx4X1TxlrltouiWbahqlwHaG1VlUsERncjcQBhVY/hXZeLPEVt46/ZjufHD+FvDega/pHiVdKhk8N2BtY5rNtO+0LFIu47yrtw/Uge5r3rwLfaR8O/wBqjSfhlpHhHQTp1ro7TJq5s86tNM+mNK98bjOShy0W3G3tnoKipiJU4u0dddO1rb/ehaHydBoV9ceF28RxQq+iLdrY/ahIv+vZPMCBc7jlec4x70s3h/UrOTSo7ixlt21ZI5bDzgFFzHI+xHXn7pbjJx0z05rqfD/h3S7j9k+9182kUusp4uttPi1IqPPW2awDmIP12lvmx612Pxj8RL4ouf2frKfStFs47nw74fklj0+yELtHNcmNoScn9xtLBUxwSxyc8aOq+blS62/C5VjyLWtHvPDusXulajELbULKVoLiHerbHU8jcCQee4OKpKQ3AYGvepfCPh3Qvir+0Dfjw/p97Y+AbK5v9G0G5iJsTJ5vlq0kSkb4oANxTOMMPQVzfjA6d4x+EXgjx4dC0jQ9c1DxVL4fvToNoLWz1KFVDiYQhiFdceUxU85HoMKNfma000182r/12Fa55Vuy3By3fnmr91oF/Y6Fpusz24j0vUpJo7S48xT5jQsFkG0Hcu0kdQM9s19JeNLfw3qfxk+Mfw1tfAvhbSNA0Lw7qOp6fe2NgV1GC9t4beQS+fu+6TOw8vGAoHvXk8Og6Z/wqf4H6qNPt11LWvFN7Y6jceWN91AmpwxJHIe6qjsoHoT60o13KKfLa9vuabX5Be+h5oGG4KCN2M7c849adgZA456cjmvpXx2vh7V9d/aC8KW/gXwzo+l+D9JvNU0S60+wMd9BcQPGCzzbsur72GzAAXA6Vw51XTPhb8K/hnfW3g7QfF1742ub46nc61Zm6dxDcpAmn2xLAQyMpJypzu5weaIYhyS93XT8r79NA17nkQxnPXtmnV6F+0doOneFv2hPiBouj6dDpGlWF9BFbWFugVIFNnbuVA/3ncn3Jrz2t4S54xn3Sf3oAprd6dTGPWrQeR758N/+RJ0z/db/ANCNdJXj/hv4qJ4f0O1046a1x5AI8xZQN2Tnpj3rS/4XZH/0B5P+/wAP8KGj5Wtgq8qkmo7s9z8B/EbxB8NdW+36DfNbM5HnW7fNDOB2dO/1HPvXtzfHD4Y/FSFI/iH4VNhqWNp1CzRnH4OmHA9iCB618Pf8LsT/AKA8n/f4f4Uf8Lsj6/2PJ/3+H+FcVbB0qz53pLutCqdDF0lyqN12Z9XfE7wL8LNJ8IXGr+CPFcmoXwmjVdMknUkqSAx2lQ/AOe9b+g+Afgbo+k6bqPiPxbPqN/JbxzS2EMxOxyoLLiJd3ByME18Zf8Lsj/6A8n/f4f4Uf8Lsj6f2M/8A3+H+FZ/VJ8ih7WXrpf8AItUKvNzexR9tap+0x4e8EabLpfwx8Kw6YhyP7QvIguf9oJncx/3z+FeB69r+o+KNWn1PVr2XUL+c5eeZsnHYD0A9BxXkP/C7E/6A8n/f4f4Uf8LsT/oDyf8Af4f4VvQwlHD3cFq+r3MquHxdaylHRdD06vOfjX/yC9K/6+G/9BNV/wDhdif9AeT/AL/D/Cuc8bePF8YWdrCLJrUwSmTc0m7PGMdK6jXC4WtTrRlKOhiaN4m1Pw7Z63bafc/Z4NasH0y/TYrefbOQXjOQcA4HIweOtTeG/GGseEYNZg0m8+y2+s2TabqNu0ayRXVucko6sCDjJweoycHk1jrRiolFO/mfSnb+Cvjb42+HmippGg60ttp0MrXFtBcWkNz9jlb70kBkUmNieTt4zzjOTXPWfi7WbM+IimozSP4itntNXlnxI95E7B3V2YE8sMkjBrJxRtpezgm7Ja76Aalx4o1O68JWPhma68zRLG8l1C1tdi4iuJFKvIGxu5UkYJxzSXXiS/1HQdG0G+lN3oGk3Es1vYcR4E0gecB1G4F8HnJwTkelZmKWrsmgPozX/wBpDSo/BfirTtI8V+LtdfW9Gm0Wy0nW7C1RdNWVQpe4u1HmXbRKCqEk5z82T81eQ+Bfi94t+G9jcWGg6okOnTyid7G8tIbqDzQMCVUkVgjgADcuM45rkAoXpS4rnhh6UE4tXTA31+IXiUeINc1yXWbi51nXLWey1K9nCvJcwzBRIhJHAIVQNoGABjFHgX4heIPhrfXd14evhZtewfZbuKWFJ4bmIHISSOQFWweQcZBJx1OefxS4rV04uLi1pp07AdV4u+K3izx4ulJr2svqC6TcNc6cogiiFmxKnEYRV2qCiYXoNtT6j8Y/F+qeM7nxbcaqp8RXVk+nT30drFGZIHBV1KqoXcwPLYyeOa47FJil7KntYDqfh/8AFDxN8MLO7svDuoR22nXbLJcWF1axXVvJIgwknlyqwDgADcMHHXOBUdv8TPFMHjiTxidbuLjxRJ5m/U51V3O+MxsNpG0DYSoAAAB4Arm6TFOUIyblZXe+gF+y16/0/wAIz+FrafytAnu476SzVVwZ402I+cZ4XjGcVnuAylSAVIwVIyD7GnYoq9LtoD0KH9oj4kW/hmLQ4fFl1BawwLapdxRxrfLCv3Y/tQXzdo/3s+5rj/FHijU/GviC+13W7r7dq184kuLkxqnmMFC52qABwo6D3rNoqI04QfNFJP0A07PxRqmn+G9X8P21z5OkatLbzX1usa5uGhbdFubG7archQQM8nNP0Txbq3h3TNf03Trs29hr1slnqUGxWW4iRiyA5B2lWYkMuCM9ayNtGKrli7q24HRWvxE8QWGpeFdRt9RaO98LW4tdGm8pM2kQDAKBjB4dh82etc8zGSR3Y5aRi7H/AGicn9SaTFLiqVr3tr/T/MCbTdRvdF1Sy1LTbu407UrGZZ7W8tXKSwSDo6sO/UehBIOQSD3fjD9oP4g+O9ButF1jxBu028Ktew2NnBaG9wcgTvEis4zyVJwe4PNefUVE6cKjUpRV0B1ngX4reKPhvbXtroGoxwWN7Is1xY3VrFdW7yqMLL5cisA4AxuGCeM5wKr2/wATPFNr40ufF39t3Enia6SWObUpgruyyIUdcEbQNvygAAKOmK5raKMUezp3bstd9ALlrrl7Y+EpfC8Eoj0GS+XUnsggwbhYhEsmcZ4jAXGcY7V3GhftE/Efw3o9npmneJDDBZw/ZbeZ7SCS4S3wR5HnMhcx8n5SeOPQV53tpaUqcKnxpP5dQL1rr9/Y+D28LQ3Hl+H2vF1BrFUXBnWPy1fdjd9z5cZxWpqHxG8R6toPhrRr7UFudP8ADUqS6QrQRiS1KNuQCQLuZVIyFYkDFc5tpcVdlfmt57deoHS2PxN8U6X46uvGNnrM1v4lupJJLm9VEIn8z/WK8ZXYysOqlccA9QKXxn8SvEfxAvNPuNc1AXC6bgWNrBDHb29ryGPlxRqFBLAEnGTjrXMbR9aMVPs6afNZX9AOkk+I/iObxZr3iZ9TLa9rlrNZajeeUmbiGVUWRCuMDcsaDgA/L1qhH4q1ZNH0HSxdn+z9BupL3TLcIuLad5RK7g4ycuqtgk9KyttGKbjG2n5fd+AHQTfEDxBPqvifUn1FmvfE9vLa6xIY0/0uKQqXUjGFyVXlQOlel/CD4uaH4H8I2uly+K/FnhWeK/e7vLbTbC31C1vwSCph83JtJdq7GdNoO4t97BHimKNorKpRhUhyNf1sB0/xS8bt8TPid4q8XtbNZnWr37StuzbmjRY0ijDHu2yNM47k1zNFFaqKilFbIApKWiqATbRtpaKBCbaNtLRQAm2jbS0UAJto20tFACbaNtLRQMQUtFFABRRRSAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD//Z";

  // Draw the RED FM logo lockup as vector (red rules + RED / FM). Returns its bottom Y.
  function drawLogo(doc, x, y, w) {
    doc.setFillColor.apply(doc, RED);
    doc.rect(x, y, w, 3.5, "F");                                  // top red rule
    doc.setTextColor(20, 20, 26); doc.setFont("helvetica", "bold");
    doc.setFontSize(30); doc.text("RED", x + w / 2, y + 32, { align: "center" });
    doc.setFontSize(13);  doc.text("F  M", x + w / 2, y + 50, { align: "center" });
    doc.setFillColor.apply(doc, RED);
    doc.rect(x, y + 58, w, 3.5, "F");                             // bottom red rule
    return y + 61.5;
  }

  // Stamp the footer (tagline + Coolstream credit + page number) on every page.
  // fgasNo (optional): Coolstream's F-Gas company certification number — shown on F-Gas certificates.
  function stampFooter(doc, fgasNo) {
    const W = doc.internal.pageSize.getWidth();
    const H = doc.internal.pageSize.getHeight();
    const n = doc.internal.getNumberOfPages();
    const credit = "Maintenance works carried out by Coolstream (UK) Ltd"
      + (fgasNo ? " · F-Gas (Refcom) No. " + fgasNo : "")
      + " on behalf of RED FM (Red Electrical Bristol Ltd).";
    for (let p = 1; p <= n; p++) {
      doc.setPage(p);
      doc.setDrawColor(225, 225, 228); doc.setLineWidth(0.5); doc.line(40, H - 40, W - 40, H - 40);
      // tagline (two-tone, italic)
      doc.setFont("times", "italic"); doc.setFontSize(10);
      doc.setTextColor(20, 20, 26); doc.text("The work that ", 40, H - 26);
      const tw = doc.getTextWidth("The work that ");
      doc.setTextColor.apply(doc, RED); doc.text("keeps you working.", 40 + tw, H - 26);
      // Coolstream credit (+ F-Gas cert number on certificates)
      doc.setFont("helvetica", "normal"); doc.setFontSize(7.5); doc.setTextColor(120, 120, 126);
      doc.text(credit, 40, H - 15);
      doc.text("Page " + p + " of " + n, W - 40, H - 15, { align: "right" });
    }
  }

  // Normalise text so jsPDF's built-in (WinAnsi) fonts can render it. Without this,
  // multi-byte characters (em dash —, smart quotes, bullets, ticks) come out as "ï¿½".
  // Latin-1 chars (£, °, é...) are left alone because the standard fonts render them fine.
  function pdfSafe(v) {
    return String(v == null ? "" : v)
      .replace(/[‒-―−]/g, "-")            // ‒–—―−  dashes/minus -> hyphen
      .replace(/[‘’‚′‵]/g, "'") // ‘’‚ primes -> '
      .replace(/[“”„″]/g, '"')       // “”„ double primes -> "
      .replace(/…/g, "...")                          // … -> ...
      .replace(/[·•∙]/g, "-")             // ·•∙ -> -
      .replace(/[✓✔]/g, "OK")                  // ✓✔ -> OK
      .replace(/[✗✘✕✖]/g, "FAULT")   // ✗✘ -> FAULT
      .replace(/ /g, " ")                            // nbsp -> space
      .replace(/[^\t\n\r\x20-\x7E¡-ÿ]/g, "");   // drop anything else non-WinAnsi
  }

  // Wrap doc.text so every string drawn (incl. autoTable cells, which draw via doc.text)
  // is sanitised. One hook covers titles, headings, table cells, meta and free-text.
  function safeText(doc) {
    if (doc.__pdfSafeWrapped) return doc;
    const orig = doc.text.bind(doc);
    doc.text = function (txt) {
      const args = Array.prototype.slice.call(arguments);
      args[0] = Array.isArray(txt) ? txt.map(pdfSafe) : pdfSafe(txt);
      return orig.apply(doc, args);
    };
    doc.__pdfSafeWrapped = true;
    return doc;
  }

  // Build a branded RED FM service-sheet PDF (Blob). Needs jsPDF + autotable loaded on the page.
  // meta: {title, subtitle, ref, date, engineer, plant, extra:[[label,value],...]}
  // sections: [{name, cols:[...], rows:[[item, v1, v2, ...]]}]  — one grid table per section, like the paper sheet.
  function buildReportPdf(meta, sections) {
    const { jsPDF } = window.jspdf;
    const doc = safeText(new jsPDF({ unit: "pt", format: "a4" }));
    const W = doc.internal.pageSize.getWidth();
    const H = doc.internal.pageSize.getHeight();

    // ---- Header: logo left, title block right ----
    drawLogo(doc, 40, 28, 150);
    doc.setTextColor(20, 20, 26); doc.setFont("helvetica", "bold"); doc.setFontSize(16);
    doc.text(meta.title || "Service report", W - 40, 46, { align: "right" });
    doc.setFont("helvetica", "normal"); doc.setFontSize(9.5); doc.setTextColor(95, 95, 102);
    doc.text(meta.subtitle || "Border Holdings, Avonmouth", W - 40, 62, { align: "right" });
    if (meta.date) doc.text("Date: " + meta.date, W - 40, 76, { align: "right" });
    doc.setDrawColor.apply(doc, RED); doc.setLineWidth(1.5); doc.line(40, 100, W - 40, 100);

    // ---- Details block ----
    // Item 9 — the issue count is DERIVED from the fault records attached to this
    // report, never from a typed value or a raw cell count. Any "Issues flagged"
    // passed in meta.extra is dropped in favour of the derived figure.
    const faults = meta.faults || [];
    const extra = (meta.extra || []).filter(([k]) => !/^issues?\s*flagged/i.test(String(k)));
    const head = [["Ref", meta.ref], ["Date", meta.date], ["Engineer", meta.engineer]]
      .concat(meta.plant ? [["Plant", meta.plant]] : []).concat(extra)
      .concat(meta.faults ? [["Faults recorded", String(faults.length)]] : []);
    doc.autoTable({
      startY: 110, theme: "plain", styles: { fontSize: 9, cellPadding: 1.5 }, margin: { left: 40, right: 40 },
      body: head.filter(([, v]) => v != null && v !== "")
        .map(([k, v]) => [{ content: k + ":", styles: { fontStyle: "bold", cellWidth: 80, textColor: [80, 80, 86] } }, String(v)])
    });

    let y = doc.lastAutoTable.finalY + 16;

    // ---- Item 8: faults summary, at the TOP, before any grid ----------------
    // Border had to scroll hunting for flagged issues and found two of six. This
    // block means every fault on the visit is on page one, with its location.
    if (meta.faults) {
      if (y > H - 140) { doc.addPage(); y = 56; }
      doc.setFont("helvetica", "bold"); doc.setFontSize(10.5); doc.setTextColor.apply(doc, RED);
      doc.text(faults.length ? "Faults recorded on this visit (" + faults.length + ")" : "Faults recorded on this visit", 40, y);
      if (!faults.length) {
        doc.setFont("helvetica", "normal"); doc.setFontSize(9); doc.setTextColor(95, 95, 102);
        doc.text("None — no line item was flagged.", 40, y + 15);
        y += 34;
      } else {
        doc.autoTable({
          startY: y + 6, margin: { left: 40, right: 40 },
          head: [["Ref", "Asset", "Location / item", "Severity", "Action taken"]],
          body: faults.map(f => [
            pdfSafe(f.ref || ""), pdfSafe(f.assetId || ""), pdfSafe(f.line || ""),
            pdfSafe(f.severity || ""), pdfSafe(f.action || "")
          ]),
          styles: { fontSize: 8, cellPadding: 3.5, overflow: "linebreak", lineColor: [225, 225, 228], lineWidth: 0.5 },
          headStyles: { fillColor: RED, textColor: 255, fontSize: 8 },
          columnStyles: {
            0: { cellWidth: 54, fontStyle: "bold" }, 1: { cellWidth: 60, fontStyle: "bold" },
            3: { cellWidth: 50 }
          },
          didParseCell: d => {
            if (d.section !== "body" || d.column.index !== 3) return;
            const v = String(d.cell.raw || "").toLowerCase();
            if (v === "high") { d.cell.styles.textColor = RED; d.cell.styles.fontStyle = "bold"; }
            else if (v === "medium") { d.cell.styles.textColor = [185, 119, 11]; d.cell.styles.fontStyle = "bold"; }
          }
        });
        y = doc.lastAutoTable.finalY + 16;
      }
      if (meta.withdrawn && meta.withdrawn.length) {
        doc.setFont("helvetica", "normal"); doc.setFontSize(8); doc.setTextColor(95, 95, 102);
        doc.text(meta.withdrawn.length + " flag(s) withdrawn as ticked in error: " +
          pdfSafe(meta.withdrawn.map(w => w.assetId + " (" + w.reason + ")").join("; ")), 40, y, { maxWidth: W - 80 });
        y += 20;
      }
    }

    // ---- One grid table per section ----
    (sections || []).forEach(s => {
      if (y > H - 90) { doc.addPage(); y = 56; }
      doc.setFont("helvetica", "bold"); doc.setFontSize(10.5); doc.setTextColor.apply(doc, RED);
      doc.text(s.name, 40, y);
      doc.autoTable({
        startY: y + 6, margin: { left: 40, right: 40 },
        head: [["Item"].concat(s.cols)],
        body: s.rows.map(r => r.map(c => String(c == null ? "" : c))),
        styles: { fontSize: 8, cellPadding: 3, overflow: "linebreak", lineColor: [225, 225, 228], lineWidth: 0.5 },
        headStyles: { fillColor: RED, textColor: 255, fontSize: 8 },
        columnStyles: { 0: { fontStyle: "bold", cellWidth: 130, textColor: [40, 40, 46] } },
        alternateRowStyles: { fillColor: [248, 248, 250] },
        // A flagged cell is unmissable whether you read the summary or scroll the sheet
        didParseCell: d => {
          if (d.section !== "body") return;
          const v = String(d.cell.raw == null ? "" : d.cell.raw).trim().toUpperCase();
          if (v === "FAULT" || v === "ISSUE") {
            d.cell.styles.fillColor = [253, 236, 238];
            d.cell.styles.textColor = RED;
            d.cell.styles.fontStyle = "bold";
          }
        }
      });
      y = doc.lastAutoTable.finalY + 16;
    });

    // Contractor (Coolstream) logo at the bottom of F-Gas certificates
    if (meta.fgasNo) {
      const lw = 120, lh = lw * 105 / 400, ly = H - 84;
      doc.setFont("helvetica", "normal"); doc.setFontSize(6.8); doc.setTextColor(120, 120, 126);
      doc.text("Refrigeration maintenance carried out by:", 40, ly - 5);
      try { doc.addImage(COOLSTREAM_LOGO, "JPEG", 40, ly, lw, lh); } catch (e) {}
      const fw = 84, fh = fw * 331 / 735, fy = H - 52 - fh;
      try { doc.addImage(FGAS_LOGO, "PNG", W - 40 - fw, fy, fw, fh); } catch (e) {}
    }
    stampFooter(doc, meta.fgasNo);
    return doc.output("blob");
  }

  // Build a branded RED FM fault report (Blob) with the photo(s) embedded.
  // meta: {ref, date, plant, severity, raisedBy, stage, description, action, subtitle}
  // photos: array of image data-URLs (jpeg/png)
  function buildFaultPdf(meta, photos) {
    const { jsPDF } = window.jspdf;
    const doc = safeText(new jsPDF({ unit: "pt", format: "a4" }));
    const W = doc.internal.pageSize.getWidth();
    const H = doc.internal.pageSize.getHeight();
    drawLogo(doc, 40, 28, 150);
    doc.setTextColor(20, 20, 26); doc.setFont("helvetica", "bold"); doc.setFontSize(16);
    doc.text("Fault report", W - 40, 46, { align: "right" });
    doc.setFont("helvetica", "normal"); doc.setFontSize(9.5); doc.setTextColor(95, 95, 102);
    doc.text(meta.subtitle || "Border Holdings, Avonmouth", W - 40, 62, { align: "right" });
    if (meta.date) doc.text("Date: " + meta.date, W - 40, 76, { align: "right" });
    doc.setDrawColor.apply(doc, RED); doc.setLineWidth(1.5); doc.line(40, 100, W - 40, 100);
    const rows = [["Ref", meta.ref], ["Date", meta.date], ["Plant", meta.plant],
      ["Severity", meta.severity], ["Raised by", meta.raisedBy], ["Stage", meta.stage || "Reported"]];
    doc.autoTable({
      startY: 110, theme: "plain", styles: { fontSize: 9, cellPadding: 1.5 }, margin: { left: 40, right: 40 },
      body: rows.filter(([, v]) => v != null && v !== "")
        .map(([k, v]) => [{ content: k + ":", styles: { fontStyle: "bold", cellWidth: 80, textColor: [80, 80, 86] } }, String(v)])
    });
    let y = doc.lastAutoTable.finalY + 16;
    function block(title, text) {
      if (!text) return;
      if (y > H - 110) { doc.addPage(); y = 56; }
      doc.setFont("helvetica", "bold"); doc.setFontSize(10.5); doc.setTextColor.apply(doc, RED); doc.text(title, 40, y); y += 15;
      doc.setFont("helvetica", "normal"); doc.setFontSize(9.5); doc.setTextColor(40, 40, 46);
      doc.splitTextToSize(text, W - 80).forEach(ln => { if (y > H - 60) { doc.addPage(); y = 56; } doc.text(ln, 40, y); y += 13; });
      y += 10;
    }
    block("Description", meta.description);
    block("Action taken / recommendation", meta.action);
    (photos || []).forEach((p, i) => {
      let props; try { props = doc.getImageProperties(p); } catch (e) { return; }
      const maxW = W - 80, maxH = 300;
      let w = maxW, h = w * props.height / props.width;
      if (h > maxH) { h = maxH; w = h * props.width / props.height; }
      if (y + 18 + h > H - 56) { doc.addPage(); y = 56; }
      doc.setFont("helvetica", "bold"); doc.setFontSize(9.5); doc.setTextColor.apply(doc, RED);
      doc.text("Photo " + (i + 1), 40, y + 10); y += 16;
      try { doc.addImage(p, props.fileType || "JPEG", 40, y, w, h); } catch (e) {}
      y += h + 14;
    });
    stampFooter(doc);
    return doc.output("blob");
  }

  return {
    init, signIn, signOut, getAccount,
    getCatalogue, saveVisit, addItem, addItemsBatch,
    getServiceVisits, getFaults, getFaultsWithId, getReadings, getCatalogueAll,
    updateFault, updateVisit, getVisitIdByRef, assetId,
    buildReportPdf, buildFaultPdf, uploadReportPdf, uploadFile
  };
})();
